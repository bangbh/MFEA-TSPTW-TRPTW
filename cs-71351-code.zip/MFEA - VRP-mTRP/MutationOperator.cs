﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Collections;
using System.IO;

namespace MFEA
{
    class MutationOperator
    {
        public ArrayList child= new ArrayList();
        public double Fitness = 0;

        public void DM(ArrayList parent, Random rand)
        {
            CycleDM(parent, rand);
        }

        public void GreedyMutation(ArrayList parent, Random rand)
        {
            ArrayList tourParent = new ArrayList();
            int random_pos = 0;
            do
                random_pos = rand.Next(parent.Count);
            while (random_pos == 0);
            child = (ArrayList)parent.Clone();
            child.Reverse(random_pos, child.Count - random_pos);
        }

        public void CycleDM(ArrayList parent, Random rand)
        {
            int i;

            int FirstRandomCut, SecondRandomCut, ThirdRandomCut;
            do
            {
                FirstRandomCut = rand.Next(parent.Count - 1);
            }
            while (FirstRandomCut <= 0);
            do
            {
                SecondRandomCut = rand.Next(parent.Count);
            }
            while (FirstRandomCut >= SecondRandomCut);

            child = (ArrayList)parent.Clone();
            child.RemoveRange(FirstRandomCut, SecondRandomCut - FirstRandomCut + 1);

            if (child.Count > 1)
            {
                do
                {
                    ThirdRandomCut = rand.Next(child.Count);
                }
                while (ThirdRandomCut <= 1);
                for (i = ThirdRandomCut; i < ThirdRandomCut + SecondRandomCut - FirstRandomCut + 1; i++)
                {
                    child.Insert(i, (int)child[i - ThirdRandomCut + FirstRandomCut]);
                }
            }
            else
            {
                child = (ArrayList)parent.Clone();
            }
        }
        public void Random_mutation(ArrayList father, Random rand)
        {

            child = (ArrayList)father.Clone();
            int reversed_pos = 0;
            do
                reversed_pos = rand.Next(father.Count);
            while (reversed_pos == 0);

            child.Reverse(reversed_pos, child.Count - reversed_pos);

            //string line = "";
            //Console.WriteLine(child.Count);

            //for (int j = 0; j < child.Count; j++)
            //{
            //    line = line + " " + child[j].ToString();
            //}
            //Console.WriteLine("BBBBBBBBBBBBBB");

            //Console.WriteLine(line);
            //Console.ReadKey();
        }
    }
}
