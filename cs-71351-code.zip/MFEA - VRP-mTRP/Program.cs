﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Globalization;
using System.Threading;
using System.Diagnostics;
using System.Runtime.Serialization.Formatters;

namespace MFEA
{
    class Program
    {
        static public Stopwatch sw = new Stopwatch();
        static public string name_file = "";
        static double total_best_sol = double.MaxValue;
        static void Main(string[] args)
        {

            ArrayList Name_File = new ArrayList();
            Random rand = new Random();
            Name_File.Add("n20w20.001.txt");
            Name_File.Add("n20w20.002.txt");
            Name_File.Add("n20w20.003.txt");
            Name_File.Add("n20w20.004.txt");
            Name_File.Add("n20w20.005.txt");

            Name_File.Add("n20w40.001.txt");
            Name_File.Add("n20w40.002.txt");
            Name_File.Add("n20w40.003.txt");
            Name_File.Add("n20w40.004.txt");
            Name_File.Add("n20w40.005.txt");

            Name_File.Add("n20w60.001.txt");
            Name_File.Add("n20w60.002.txt");
            Name_File.Add("n20w60.003.txt");
            Name_File.Add("n20w60.004.txt");
            Name_File.Add("n20w60.005.txt");

            Name_File.Add("n20w80.001.txt");
            Name_File.Add("n20w80.002.txt");
            Name_File.Add("n20w80.003.txt");
            Name_File.Add("n20w80.004.txt");
            Name_File.Add("n20w80.005.txt");

            Name_File.Add("n20w100.001.txt");
            Name_File.Add("n20w100.002.txt");
            Name_File.Add("n20w100.003.txt");
            Name_File.Add("n20w100.004.txt");
            Name_File.Add("n20w100.005.txt");

            Name_File.Add("n20w120.001.txt");
            Name_File.Add("n20w120.002.txt");
            Name_File.Add("n20w120.003.txt");
            Name_File.Add("n20w120.004.txt");
            Name_File.Add("n20w120.005.txt");

            Name_File.Add("n20w140.001.txt");
            Name_File.Add("n20w140.002.txt");
            Name_File.Add("n20w140.003.txt");
            Name_File.Add("n20w140.004.txt");
            Name_File.Add("n20w140.005.txt");

            Name_File.Add("n20w160.001.txt");
            Name_File.Add("n20w160.002.txt");
            Name_File.Add("n20w160.003.txt");
            Name_File.Add("n20w160.004.txt");
            Name_File.Add("n20w160.005.txt");

            Name_File.Add("n20w180.001.txt");
            Name_File.Add("n20w180.002.txt");
            Name_File.Add("n20w180.003.txt");
            Name_File.Add("n20w180.004.txt");
            Name_File.Add("n20w180.005.txt");

            Name_File.Add("n20w200.001.txt");
            Name_File.Add("n20w200.002.txt");
            Name_File.Add("n20w200.003.txt");
            Name_File.Add("n20w200.004.txt");
            Name_File.Add("n20w200.005.txt");


            Name_File.Add("n40w20.001.txt");
            Name_File.Add("n40w20.002.txt");
            Name_File.Add("n40w20.003.txt");
            Name_File.Add("n40w20.004.txt");
            Name_File.Add("n40w20.005.txt");

            Name_File.Add("n40w40.001.txt");
            Name_File.Add("n40w40.002.txt");
            Name_File.Add("n40w40.003.txt");
            Name_File.Add("n40w40.004.txt");
            Name_File.Add("n40w40.005.txt");

            Name_File.Add("n40w60.001.txt");
            Name_File.Add("n40w60.002.txt");
            Name_File.Add("n40w60.003.txt");
            Name_File.Add("n40w60.004.txt");
            Name_File.Add("n40w60.005.txt");

            Name_File.Add("n40w80.001.txt");
            Name_File.Add("n40w80.002.txt");
            Name_File.Add("n40w80.003.txt");
            Name_File.Add("n40w80.004.txt");
            Name_File.Add("n40w80.005.txt");

            Name_File.Add("n40w100.001.txt");
            Name_File.Add("n40w100.002.txt");
            Name_File.Add("n40w100.003.txt");
            Name_File.Add("n40w100.004.txt");
            Name_File.Add("n40w100.005.txt");

            Name_File.Add("n40w120.001.txt");
            Name_File.Add("n40w120.002.txt");
            Name_File.Add("n40w120.003.txt");
            Name_File.Add("n40w120.004.txt");
            Name_File.Add("n40w120.005.txt");

            Name_File.Add("n40w140.001.txt");
            Name_File.Add("n40w140.002.txt");
            Name_File.Add("n40w140.003.txt");
            Name_File.Add("n40w140.004.txt");
            Name_File.Add("n40w140.005.txt");

            Name_File.Add("n40w160.001.txt");
            Name_File.Add("n40w160.002.txt");
            Name_File.Add("n40w160.003.txt");
            Name_File.Add("n40w160.004.txt");
            Name_File.Add("n40w160.005.txt");

            Name_File.Add("n40w180.001.txt");
            Name_File.Add("n40w180.002.txt");
            Name_File.Add("n40w180.003.txt");
            Name_File.Add("n40w180.004.txt");
            Name_File.Add("n40w180.005.txt");

            Name_File.Add("n40w200.001.txt");
            Name_File.Add("n40w200.002.txt");
            Name_File.Add("n40w200.003.txt");
            Name_File.Add("n40w200.004.txt");
            Name_File.Add("n40w200.005.txt");


            Name_File.Add("n60w20.001.txt");
            Name_File.Add("n60w20.002.txt");
            Name_File.Add("n60w20.003.txt");
            Name_File.Add("n60w20.004.txt");
            Name_File.Add("n60w20.005.txt");

            Name_File.Add("n60w40.001.txt");
            Name_File.Add("n60w40.002.txt");
            Name_File.Add("n60w40.003.txt");
            Name_File.Add("n60w40.004.txt");
            Name_File.Add("n60w40.005.txt");

            Name_File.Add("n60w60.001.txt");
            Name_File.Add("n60w60.002.txt");
            Name_File.Add("n60w60.003.txt");
            Name_File.Add("n60w60.004.txt");
            Name_File.Add("n60w60.005.txt");

            Name_File.Add("n60w80.001.txt");
            Name_File.Add("n60w80.002.txt");
            Name_File.Add("n60w80.003.txt");
            Name_File.Add("n60w80.004.txt");
            Name_File.Add("n60w80.005.txt");

            Name_File.Add("n60w100.001.txt");
            Name_File.Add("n60w100.002.txt");
            Name_File.Add("n60w100.003.txt");
            Name_File.Add("n60w100.004.txt");
            Name_File.Add("n60w100.005.txt");

            Name_File.Add("n60w120.001.txt");
            Name_File.Add("n60w120.002.txt");
            Name_File.Add("n60w120.003.txt");
            Name_File.Add("n60w120.004.txt");
            Name_File.Add("n60w120.005.txt");

            Name_File.Add("n60w140.001.txt");
            Name_File.Add("n60w140.002.txt");
            Name_File.Add("n60w140.003.txt");
            Name_File.Add("n60w140.004.txt");
            Name_File.Add("n60w140.005.txt");

            Name_File.Add("n60w160.001.txt");
            Name_File.Add("n60w160.002.txt");
            Name_File.Add("n60w160.003.txt");
            Name_File.Add("n60w160.004.txt");
            Name_File.Add("n60w160.005.txt");

            Name_File.Add("n60w180.001.txt");
            Name_File.Add("n60w180.002.txt");
            Name_File.Add("n60w180.003.txt");
            Name_File.Add("n60w180.004.txt");
            Name_File.Add("n60w180.005.txt");

            Name_File.Add("n60w200.001.txt");
            Name_File.Add("n60w200.002.txt");
            Name_File.Add("n60w200.003.txt");
            Name_File.Add("n60w200.004.txt");
            Name_File.Add("n60w200.005.txt");

            //Name_File.Add("n80w20.001.txt");
            //Name_File.Add("n80w20.002.txt");
            //Name_File.Add("n80w20.003.txt");
            //Name_File.Add("n80w20.004.txt");
            //Name_File.Add("n80w20.005.txt");

            //Name_File.Add("n80w40.001.txt");
            //Name_File.Add("n80w40.002.txt");
            //Name_File.Add("n80w40.003.txt");
            //Name_File.Add("n80w40.004.txt");
            //Name_File.Add("n80w40.005.txt");

            //Name_File.Add("n80w60.001.txt");
            //Name_File.Add("n80w60.002.txt");
            //Name_File.Add("n80w60.003.txt");
            //Name_File.Add("n80w60.004.txt");
            //Name_File.Add("n80w60.005.txt");

            //Name_File.Add("n80w80.001.txt");
            //Name_File.Add("n80w80.002.txt");
            //Name_File.Add("n80w80.003.txt");
            //Name_File.Add("n80w80.004.txt");
            //Name_File.Add("n80w80.005.txt");

            //Name_File.Add("n80w100.001.txt");
            //Name_File.Add("n80w100.002.txt");
            //Name_File.Add("n80w100.003.txt");
            //Name_File.Add("n80w100.004.txt");
            //Name_File.Add("n80w100.005.txt");

            //Name_File.Add("n80w120.001.txt");
            //Name_File.Add("n80w120.002.txt");
            //Name_File.Add("n80w120.003.txt");
            //Name_File.Add("n80w120.004.txt");
            //Name_File.Add("n80w120.005.txt");

            //Name_File.Add("n80w140.001.txt");
            //Name_File.Add("n80w140.002.txt");
            //Name_File.Add("n80w140.003.txt");
            //Name_File.Add("n80w140.004.txt");
            //Name_File.Add("n80w140.005.txt");

            //Name_File.Add("n80w160.001.txt");
            //Name_File.Add("n80w160.002.txt");
            //Name_File.Add("n80w160.003.txt");
            //Name_File.Add("n80w160.004.txt");
            //Name_File.Add("n80w160.005.txt");

            //Name_File.Add("n80w180.001.txt");
            //Name_File.Add("n80w180.002.txt");
            //Name_File.Add("n80w180.003.txt");
            //Name_File.Add("n80w180.004.txt");
            //Name_File.Add("n80w180.005.txt");

            //Name_File.Add("n80w200.001.txt");
            //Name_File.Add("n80w200.002.txt");
            //Name_File.Add("n80w200.003.txt");
            //Name_File.Add("n80w200.004.txt");
            //Name_File.Add("n80w200.005.txt");
            //Name_File.Add("n100w20.001.txt");

            //Name_File.Add("n100w20.001.txt");
            //Name_File.Add("n100w20.002.txt");
            //Name_File.Add("n100w20.003.txt");
            //Name_File.Add("n100w20.004.txt");
            //Name_File.Add("n100w20.005.txt");

            //Name_File.Add("n100w40.001.txt");
            //Name_File.Add("n100w40.002.txt");
            //Name_File.Add("n100w40.003.txt");
            //Name_File.Add("n100w40.004.txt");
            //Name_File.Add("n100w40.005.txt");

            //Name_File.Add("n100w60.001.txt");
            //Name_File.Add("n100w60.002.txt");
            //Name_File.Add("n100w60.003.txt");
            //Name_File.Add("n100w60.004.txt");
            //Name_File.Add("n100w60.005.txt");

            //Name_File.Add("n100w120.001.txt");
            //Name_File.Add("n100w120.002.txt");
            //Name_File.Add("n100w120.003.txt");
            //Name_File.Add("n100w120.004.txt");
            //Name_File.Add("n100w140.001.txt");
            //Name_File.Add("n100w140.002.txt");
            //Name_File.Add("n100w140.003.txt");
            //Name_File.Add("n100w140.004.txt");

            //Name_File.Add("n150w20.001.txt"); 
            //Name_File.Add("n150w20.002.txt");
            //Name_File.Add("n150w20.003.txt"); Name_File.Add("n150w20.004.txt");
            //Name_File.Add("n150w40.001.txt"); Name_File.Add("n150w40.002.txt");
            //Name_File.Add("n150w40.003.txt"); Name_File.Add("n150w40.004.txt");

            for (int i = 0; i < Name_File.Count; i++)
            {
                Console.WriteLine((string)Name_File[i]);
                name_file = (string)Name_File[i];
                int nearest_vertex_number = 10;
                Program.total_best_sol = double.MaxValue;
                Population.best_TRP = double.MaxValue;
                Population.best_TSP = double.MaxValue;
                sw.Restart();
                int start_vertex;
                for (start_vertex = 0; start_vertex < 1; start_vertex++)
                {
                    Console.WriteLine("Dinh xuat phat " + start_vertex.ToString());
                    do
                    {
                        nearest_vertex_number = rand.Next(10);
                    } while (nearest_vertex_number <= 1);
                    nearest_vertex_number = 10;
                    Rdata rdata = new Rdata();
                    rdata.read_data_Set((string)Name_File[i], nearest_vertex_number);
                    rdata.Calculate_nearest_distance(nearest_vertex_number);
                    rdata.change_distance();
                    int k_vehicle = 1;
                    Program pro = new Program();
                    Tour initial_tour = new Tour();
                    //int k_vehicle = 1;
                    //initial_tour.Initial_tour_find(k_vehicle, start_vertex, nearest_vertex_number, rdata.Lvertex, rdata.D, rdata.Q);
                    sw.Start();
                    pro.MFEA(k_vehicle, start_vertex, nearest_vertex_number, rdata, 0.7, rand);
                    sw.Stop();
                    pro.write_file(sw.ElapsedMilliseconds / 1000, Population.best_TSP, Population.best_TSP_Sol, Population.best_TRP, Population.best_TRP_Sol);
                }
            }
        }

        public void MFEA(int k_vehicle, int start_vertex, int nearest_vertex_number, Rdata rdata, double rmp, Random rand)
        {
            int i, j, k, popluation_size = 10;
            Population parent_population = new Population();
            parent_population = parent_population.Init_population(k_vehicle, popluation_size, start_vertex, nearest_vertex_number, rdata, rand);
            parent_population = (Population) parent_population.Clear_population(popluation_size);
            parent_population.Rank_population();

            k_vehicle = 1;
            int generation = 0;
            while (true)
            {
                Population child_population = new Population();
                int child_number = 0;
                //Console.WriteLine("generation");
                //Console.WriteLine(generation);

                while (child_number < popluation_size)
                {
                    Tour father_tour = new Tour();
                    Tour mother_tour = new Tour();
                    Tour boy_tour = new Tour();
                    Tour girl_tour = new Tour();

                    ArrayList parent_indexes = (ArrayList)parent_population.selection_operator(5, rand);
                    father_tour = (Tour)parent_population[(int)parent_indexes[0]];
                    mother_tour = (Tour)parent_population[(int)parent_indexes[1]];

                    //Console.WriteLine(parent_population.selection_operator(5, rand)[0]);
                    //Console.WriteLine(parent_population.selection_operator(5, rand)[1]);
                    //Console.WriteLine("crossover");

                    double crossover_proba = rand.NextDouble();
                    if ((father_tour.skill_factor == mother_tour.skill_factor) || (crossover_proba < 70))
                    {
                        CrossoverOperator CO = new CrossoverOperator();
                        int crossover_opertor = rand.Next(2);
                        //CO.POS(father_tour.Ltour, mother_tour.Ltour);
                        //crossover_opertor = 2;
                        if (crossover_opertor == 0)
                        {
                            //Console.WriteLine("POS");
                            CO.POS(father_tour.Ltour, mother_tour.Ltour);
                        }
                        else
                        {
                          CO.OX(father_tour.Ltour, mother_tour.Ltour);

                            if (crossover_opertor == 1)
                            {
                                //Console.WriteLine("OX");
                                CO.OX(father_tour.Ltour, mother_tour.Ltour);
                            }
                            else
                            {
                                //Console.WriteLine("MPX"); //Console.ReadKey();
                                CO.MPX(father_tour.Ltour, mother_tour.Ltour);
                            }
                        }
                        //CO.OX(father_tour.Ltour, mother_tour.Ltour, 2);
                        boy_tour.Ltour = (ArrayList)CO.boy_tour.Clone();
                        girl_tour.Ltour = (ArrayList)CO.girl_tour.Clone();

                        int skill_factor_selection = rand.Next(2);
                        
                        if (skill_factor_selection == 0)
                        {
                            boy_tour.skill_factor = father_tour.skill_factor;
                            girl_tour.skill_factor = mother_tour.skill_factor;
                        }
                        else
                        {
                            girl_tour.skill_factor = father_tour.skill_factor;
                            boy_tour.skill_factor = mother_tour.skill_factor;
                        }
                    }
                    else
                    {
                        //Console.WriteLine("Mutation");

                        MutationOperator MO = new MutationOperator();
                        int mutation_opertor = rand.Next(2);
                        //CO.POS(father_tour.Ltour, mother_tour.Ltour);

                        if (mutation_opertor == 0)
                        {
                            MO.Random_mutation(father_tour.Ltour, rand);
                            boy_tour.Ltour = (ArrayList)MO.child.Clone();
                        }
                        else
                        {
                            MO.DM(father_tour.Ltour, rand);
                            boy_tour.Ltour = (ArrayList)MO.child.Clone();
                        }

                        mutation_opertor = rand.Next(2);
                        //CO.POS(father_tour.Ltour, mother_tour.Ltour);

                        if (mutation_opertor == 0)
                        {
                            MO.Random_mutation(mother_tour.Ltour, rand);
                            girl_tour.Ltour = (ArrayList)MO.child.Clone();
                        }
                        else
                        {
                            MO.DM(mother_tour.Ltour, rand);
                            girl_tour.Ltour = (ArrayList)MO.child.Clone();
                        }

                        boy_tour.skill_factor = father_tour.skill_factor;
                        girl_tour.skill_factor = mother_tour.skill_factor;
                    }

                    boy_tour.fac_cost.Clear(); 
                    girl_tour.fac_cost.Clear();
                    if (boy_tour.check_fessible_sol(boy_tour.Ltour, rdata.Lvertex, Program.name_file) == false)
                    {
                        //Console.WriteLine("repair");
                        boy_tour.Ltour = boy_tour.repair_tour(boy_tour.Ltour, rdata.Lvertex, Program.name_file);
                        //Console.ReadKey();
                    }
                    if (girl_tour.check_fessible_sol(girl_tour.Ltour, rdata.Lvertex, Program.name_file) == false)
                    {
                        //Console.WriteLine("repair");
                        girl_tour.Ltour = girl_tour.repair_tour(girl_tour.Ltour, rdata.Lvertex, Program.name_file);
                        //Console.ReadKey();
                    }

                    boy_tour.Calculate_fac_TSP(rdata.Lvertex);
                    boy_tour.Calculate_fac_TRP(rdata.Lvertex);

                    girl_tour.Calculate_fac_TSP(rdata.Lvertex);
                    girl_tour.Calculate_fac_TRP(rdata.Lvertex);

                    child_population.Add(boy_tour);
                    child_population.Add(girl_tour);
                    child_number++;
                }
                //child_population.Rank_population();
                //Console.WriteLine("VNS"); 
                child_population.Rank_population();
                child_population.Sort_population();
                //child_population.print(); Console.ReadKey();
                for (i = 0; i < 5; i++)
                {
                    RVNS rVNS = new RVNS();
                    //if (rand.Next(100) > 50)
                    //{
                    //if (child_population[i].rank < 1)
                    //{
                    //child_population[i] = 
                    //Console.WriteLine("VNS");
                    //Console.WriteLine(child_population[i].Ltour.Count);
                    rVNS.VNS(rdata.Lvertex, (Tour)child_population[i]);
                    //}
                    //}
                    //parent_population.Add((Tour)child_population[i]);
                }
                for (i = 0; i < child_population.Count; i++)
                {
                    parent_population.Add((Tour)child_population[i]);
                }
                //Console.WriteLine("Out VNS"); //Console.ReadKey();
                //Console.ReadKey();
                parent_population.Elite_population(popluation_size, rand, rdata.Lvertex);
                //parent_population.print();
                generation++;
                //Console.WriteLine("generation");
                //Console.WriteLine(generation);
                //write_file(Program.sw.ElapsedMilliseconds / 1000, Program.name_file, 1, Population.best_TSP, generation);
                //write_file(Program.sw.ElapsedMilliseconds / 1000, Program.name_file, 2, Population.best_TRP, generation);

                if (generation == 10) break;
                //Console.ReadKey();
            }
            //calculate rank
        }

        public void write_file(double running_time, double fac_TSP, ArrayList TSP_sol, double fac_TRP, ArrayList TRP_sol)
        {

            StreamWriter sr = new StreamWriter("TSP-MFEA-Best.txt", true);
            StreamWriter sr1 = new StreamWriter("TRP-MFEA-Best.txt", true);
          
            string TSP_str = "";
            for (int i = 0; i < TSP_sol.Count; i++)
            {
                TSP_str = TSP_str + TSP_sol[i] + " ";
            }

            string TRP_str = "";
            for (int i = 0; i < TRP_sol.Count; i++)
            {
                TRP_str = TRP_str + TRP_sol[i] + " ";
            }

            try
            {
                sr.WriteLine(running_time.ToString() + "----" + fac_TSP.ToString() + "----" + TSP_str);
                sr1.WriteLine(running_time.ToString() + "----" + fac_TRP.ToString() + "----" + TRP_str);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            sr.Close();sr1.Close();
        }

        public void write_file(double running_time, string name_instances, int num, double fac, int generation)
        {
            string str;
            if (num == 1)
                str = "TSP-MFEA-time-" + name_instances;
            else
                str = "TRP-MFEA-time-" + name_instances;

            StreamWriter sr = new StreamWriter(str, true);

            try
            {
                sr.WriteLine(running_time.ToString() + "----" + fac.ToString() + "----" + generation.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            sr.Close();
        }
        public double latency_tour(ArrayList tour, ArrayList Lvertex)
        {
            double total_fac_TRP = 0;
            for (int i = 0; i < tour.Count - 1; i++)
            {
                double fac_TRP = 0;
                Route route = new Route();

                double fac_TRP_route = 0;
                route = (Route) tour[i];
                
                for (int j = 0; j < route.Lroute.Count - 1; j++)
                {
                    fac_TRP_route = fac_TRP_route + (double)(route.Lroute.Count - 1 - j) * (double)((Vertex)Lvertex[(int)route.Lroute[i]]).distance_vertex_list[(int)route.Lroute[i + 1]];
                }
                fac_TRP = fac_TRP + fac_TRP_route;
                total_fac_TRP = total_fac_TRP + fac_TRP;
            }

            return total_fac_TRP;
        }


    }
}

