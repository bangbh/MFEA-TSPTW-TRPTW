﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Globalization;
using System.Threading.Tasks;
namespace MFEA
{
    class Rdata
    {
        public ArrayList Lvertex = new ArrayList();
        public int Nvertex = 0;
        public int cus_num = 0;
        public int de_num = 0;
        public double Q = 0;
        public double D = 0;
        public int k_vehicle = 0;
        static public int number_vertices = 0;

        public void read_data_Set(string file_name, int nearest_vertex_number)
        {
            double x, y;
            int i, j, k = 0;
            number_vertices = 0;
            //Console.WriteLine(file_name);
            ArrayList temp_start_time = new ArrayList();

            string fileContent = File.ReadAllText(file_name);
            //Console.WriteLine(fileContent);
            fileContent = fileContent.TrimStart();
            fileContent = fileContent.TrimEnd();
            string[] doubleStrings = fileContent.Split(new char[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            //Console.WriteLine(doubleStrings[0]);

            double[] doubles = new double[doubleStrings.Length];

            for (int n = 15; n < doubleStrings.Length; n++)
            {
                doubles[n] = double.Parse(doubleStrings[n]);
                //Console.WriteLine(doubleStrings[n]);
            }

            i = 15;
            //this.Add(new vertex(0, 0, 0, 0, 0));
            while (doubles[i] != 999)
            {
                int pos = (int)doubles[i] - 1;
                x = (double)doubles[i + 1];
                y = (double)doubles[i + 2];
                double demand_time = (double)doubles[i + 3];
                double start_time = (double)doubles[i + 4];
                double end_time = (double)doubles[i + 5];
                double service_time = (double)doubles[i + 6];

                //Console.WriteLine(pos);
                //Console.WriteLine(x);
                //Console.WriteLine(y);
                //Console.WriteLine(demand_time);
                //Console.WriteLine(start_time);
                //Console.WriteLine(end_time);
                //Console.WriteLine(service_time);

                this.Lvertex.Add(new Vertex(pos, x, y, start_time, end_time, service_time, demand_time));
                number_vertices++;
                i = i + 7;
                //temp_start_time.Add(start_time);
                //Console.ReadKey();
            }

        }
        public void Calculate_nearest_distance(int nearest_vertex_number)
        {
            //dmax = double.MinValue;
            //Console.WriteLine(nearest_vertex_number);
            //Console.WriteLine("BHB");
            for (int i = 0; i < this.Lvertex.Count; i++)
            {
                Vertex vertex_i = new Vertex(0, 0, 0, 0, 0, 0, 0);
                vertex_i = (Vertex)this.Lvertex[i];

                vertex_i.distance_vertex_list.Clear();

                for (int j = 0; j < this.Lvertex.Count; j++)
                {
                    Vertex vertex_j = new Vertex(0, 0, 0, 0, 0, 0, 0);
                    vertex_j = (Vertex)this.Lvertex[j];

                    double dist = (double)(Math.Truncate(Math.Sqrt(Math.Pow((double)(vertex_i.x - vertex_j.x), 2D) +
                                        Math.Pow((double)(vertex_i.y - vertex_j.y), 2D))));
                    vertex_i.distance_vertex_list.Add(dist);
                    //Console.WriteLine(dist);
                }
            }

            foreach (Vertex vertex in Lvertex)
            {
                //Console.WriteLine(nearest_vertex_number);
                vertex.Nearest_vertex_find(nearest_vertex_number);
            }
            //Console.ReadKey();
        }

        public void change_distance()
        {
            int i, j, k;
            for (i = 0; i < this.Lvertex.Count; i++)
                for (j = 0; j < this.Lvertex.Count; j++)
                    for (k = 0; k < this.Lvertex.Count; k++)
                    {
                        if ((double)((Vertex)this.Lvertex[i]).distance_vertex_list[j] > ((double)((Vertex)this.Lvertex[i]).distance_vertex_list[k] + (double)((Vertex)this.Lvertex[k]).distance_vertex_list[j]))
                        {
                            ((Vertex)this.Lvertex[i]).distance_vertex_list[j] = (double)((Vertex)this.Lvertex[i]).distance_vertex_list[k] + (double)((Vertex)this.Lvertex[k]).distance_vertex_list[j];
                            //Console.WriteLine("BHB");
                        }
                        //Console.WriteLine((double)((vertex)this[i]).distance_vertices[j]);
                        //Console.ReadKey();
                    }

        }
    }

}
