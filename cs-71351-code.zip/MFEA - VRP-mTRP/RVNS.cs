﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Globalization;
using System.Threading;
using System.Diagnostics;

namespace MFEA
{
    class RVNS
    {
        static bool best_found = false;

        public Tour VNS_TSP(ArrayList Lvertex, Tour child)
        {

            double pre_scalar_fitness = double.MaxValue;

            Tour pre_current_tour = new Tour();
            Tour pos_current_tour = new Tour();
            Tour total_crrent_tour = new Tour();

            int diversity_value = 10;
            Random rand = new Random();
            int generation = 0;
            int l = 10;

            pre_current_tour = deep_copy(child);

            while (generation < 1)
            {
                //Console.WriteLine("improved_VND");
                pos_current_tour = improved_VND(pre_current_tour, pre_scalar_fitness, Lvertex, rand, 0, 0, l);
                //Console.WriteLine("simple_swap_mutation");
                pos_current_tour = (Tour)simple_swap_mutation(pos_current_tour, Lvertex, rand, diversity_value);


                pos_current_tour = (Tour)clear_tour(pos_current_tour);
                pos_current_tour.Calculate_fac_TSP(Lvertex);
                pos_current_tour.Calculate_fac_TRP(Lvertex);
                pre_current_tour = deep_copy(pos_current_tour);
                generation++;
                //Console.WriteLine("Out VNS");
                //Console.WriteLine(generation);

            }
            return deep_copy(pos_current_tour);
        }

        public Tour VNS(ArrayList Lvertex, Tour child)
        {

            double pre_scalar_fitness = double.MaxValue;

            Tour pre_current_tour = new Tour();
            Tour pos_current_tour = new Tour();
            Tour total_crrent_tour = new Tour();

            int diversity_value = 10;
            Random rand = new Random();
            int generation = 0;
            int l = 10;

            pre_current_tour = deep_copy(child);

            while (generation < 1)
            {
                //Console.WriteLine("improved_VND_TSP");
                pos_current_tour = light_improved_VND_TSP(pre_current_tour, pre_scalar_fitness, Lvertex, rand, 0, 0, l);
                //Console.WriteLine("improved_VND_TRP");
                pos_current_tour = light_improved_VND_TRP(pre_current_tour, pre_scalar_fitness, Lvertex, rand, 0, 0, l);
                //Console.WriteLine("simple_swap_mutation");
                pos_current_tour = (Tour)simple_swap_mutation(pos_current_tour, Lvertex, rand, diversity_value);
                
                pos_current_tour = (Tour) clear_tour(pos_current_tour);
                if(pos_current_tour.check_fessible_sol(pos_current_tour.Ltour, Lvertex, Program.name_file) == false)
                {
                    //Console.WriteLine("CHECK CHECK CHECK");
                    pos_current_tour.Ltour = pos_current_tour.repair_tour(pos_current_tour.Ltour, Lvertex, Program.name_file);
                }
                pos_current_tour.Calculate_fac_TSP(Lvertex);
                pos_current_tour.Calculate_fac_TRP(Lvertex);
                pre_current_tour = deep_copy(pos_current_tour);
                generation++;
                //Console.WriteLine("Out VNS");
                //Console.WriteLine(generation);
            }
            return deep_copy(pos_current_tour);
        }


        public double cost_TSP(ArrayList tour, ArrayList Lvertex)
        {

            bool fessible = true;
            double cpk = 0;
            double dpk = 0;
            double fac_TSP = 0;

            //string st = "";
            /*
            for (int i = 0; i < Tour.Count; i++)
            {
                st = st + Tour[i] + " ";
                //Console.WriteLine((double)VertexList[(int)Tour[i]].service_time);
            }
            Console.WriteLine(st);
            */
            if (dpk < ((Vertex)Lvertex[(int)tour[0]]).start_time)
            {
                dpk = ((Vertex)Lvertex[(int)tour[0]]).start_time;
            }

            //length = (double)((Vertex)rdata.Lvertex[(int)Tour[0]]).distance_vertex_list[(int)Tour[1]];
            for (int i = 1; i < Lvertex.Count; i++)
            {
                cpk = (double)((Vertex)Lvertex[(int)tour[i - 1]]).distance_vertex_list[(int)tour[i]]// +
                    + (double)((Vertex)Lvertex[(int)tour[i - 1]]).service_time;
                //Console.WriteLine("Tour");
                //Console.WriteLine(cpk);
                //Console.WriteLine(VertexList[2].end_time);
                //Console.ReadKey();
                //Console.WriteLine(VertexList[(int)Tour[i]].end_time);
                dpk = dpk + cpk;
                if (dpk < ((Vertex)Lvertex[(int)tour[i]]).start_time)
                {
                    dpk = ((Vertex)Lvertex[(int)tour[i]]).start_time;
                }
                if (dpk > ((Vertex)Lvertex[(int)tour[i]]).end_time)
                {
                    fessible = false;
                }
                dpk = dpk - ((Vertex)Lvertex[(int)tour[0]]).start_time;
                fac_TSP = fac_TSP + (double)((Vertex)Lvertex[(int)tour[i - 1]]).distance_vertex_list[(int)tour[i]];
            }
            fac_TSP = fac_TSP + (double)((Vertex)Lvertex[(int)tour[tour.Count - 1]]).distance_vertex_list[(int)tour[0]];

            if ((fac_TSP < Population.best_TSP) && (fessible == true))
            {
                //write_file(Program.sw.ElapsedMilliseconds / 1000, Program.name_file, 1, fac_TSP, sol_str);
                Population.best_TSP = fac_TSP;
                Console.WriteLine("Population.best_TSP");
                Console.WriteLine(Population.best_TSP);
            }
            //Console.ReadKey();
            return (fac_TSP);
        }


        public double cost_TRP(ArrayList tour, ArrayList Lvertex)
        {
            bool fessible = true;
            double cpk = 0;
            double dpk = 0;
            double fac_TRP = 0;
            //string st = "";
            /*
            for (int i = 0; i < Tour.Count; i++)
            {
                st = st + Tour[i] + " ";
                //Console.WriteLine((double)VertexList[(int)Tour[i]].service_time);
            }
            Console.WriteLine(st);
            */
            if (dpk < ((Vertex)Lvertex[(int)tour[0]]).start_time)
            {
                dpk = ((Vertex)Lvertex[(int)tour[0]]).start_time;
            }

            //length = (double)((Vertex)rdata.Lvertex[(int)Tour[0]]).distance_vertex_list[(int)Tour[1]];
            for (int i = 1; i < Lvertex.Count; i++)
            {
                cpk = (double)((Vertex)Lvertex[(int)tour[i - 1]]).distance_vertex_list[(int)tour[i]]// +
                    + (double)((Vertex)Lvertex[(int)tour[i - 1]]).service_time;
                //Console.WriteLine("Tour");
                //Console.WriteLine(cpk);
                //Console.WriteLine(VertexList[2].end_time);
                //Console.ReadKey();
                //Console.WriteLine(VertexList[(int)Tour[i]].end_time);
                dpk = dpk + cpk;
                if (dpk < ((Vertex)Lvertex[(int)tour[i]]).start_time)
                {
                    dpk = ((Vertex)Lvertex[(int)tour[i]]).start_time;
                }
                if (dpk > ((Vertex)Lvertex[(int)tour[i]]).end_time)
                {
                    fessible = false;
                }
                dpk = dpk - ((Vertex)Lvertex[(int)tour[0]]).start_time;
                fac_TRP = fac_TRP + dpk;
            }

            if ((fac_TRP < Population.best_TRP) && (fessible == true))
            {
                //write_file(Program.sw.ElapsedMilliseconds / 1000, Program.name_file, 1, fac_TSP, sol_str);
                Population.best_TRP = fac_TRP;
                Console.WriteLine("Population.best_TRP");
                Console.WriteLine(Population.best_TRP);
            }
            //Console.ReadKey();
            return (fac_TRP);
        }

        public bool check_fessible_sol(ArrayList tour, ArrayList Lvertex, string fileName)
        {
            //Console.WriteLine(fileName);

            bool fessible = true;
            double cpk = 0;
            double dpk = 0;

            //string st = "";
            /*
            for (int i = 0; i < Tour.Count; i++)
            {
                st = st + Tour[i] + " ";
                //Console.WriteLine((double)VertexList[(int)Tour[i]].service_time);
            }
            Console.WriteLine(st);
            */
            if (dpk < ((Vertex)Lvertex[(int)tour[0]]).start_time)
            {
                dpk = ((Vertex)Lvertex[(int)tour[0]]).start_time;
            }

            for (int i = 1; i < tour.Count; i++)
            {
                cpk = (double)((Vertex)Lvertex[(int)tour[i - 1]]).distance_vertex_list[(int)tour[i]]// +
                    + (double)((Vertex)Lvertex[(int)tour[i - 1]]).service_time;
                dpk = dpk + cpk;
                if (dpk < ((Vertex)Lvertex[(int)tour[i]]).start_time)
                {
                    dpk = ((Vertex)Lvertex[(int)tour[i]]).start_time;
                }
                if (dpk > ((Vertex)Lvertex[(int)tour[i]]).end_time)
                {
                    fessible = false;
                    break;
                }
                dpk = dpk - ((Vertex)Lvertex[(int)tour[0]]).start_time;
            }

            return (fessible);
        }

        public Tour light_improved_VND_TRP(Tour current_tour, double current_latency, ArrayList Lvertex, Random rand, int k, int neighborhood_Restriction, int l)
        {
            Tour pre_current_tour = new Tour();

            pre_current_tour = deep_copy(current_tour);

            for (int i = 0; i < 5; i++)
            {
                best_found = false;
                //write_file(namefile); write_file_1(namefile);
                Tour pos_current_tour = new Tour();
                if (i == 0)
                {
                    //Console.WriteLine("swap_adjacent");
                    pos_current_tour = swap_TRP(pre_current_tour, Lvertex);
                    if (best_found)
                    {
                        pre_current_tour = deep_copy(pos_current_tour);
                        i = 0;
                        //print(pre_current_tour);
                        //update
                        if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                        {
                            Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                            //Console.WriteLine("Population.best_TRP");
                            //Console.WriteLine(Population.best_TRP);
                        }
                    }
                }
                else
                {
                    if (i == 1)
                    {
                        //Console.WriteLine("swap_TRP");
                        pos_current_tour = remove_insert_TRP(pre_current_tour, Lvertex);
                        if (best_found)
                        {
                            pre_current_tour = deep_copy(pos_current_tour);
                            i = 0;
                            //print(pre_current_tour);
                            //Console.ReadKey();
                            //update
                            if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                            {
                                Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                //Console.WriteLine("Population.best_TRP");
                                //Console.WriteLine(Population.best_TRP);
                            }
                        }
                    }
                    else
                    {
                        if (i == 2)
                        {
                            //Console.WriteLine("move_up_full");
                            pos_current_tour = first_or_TRP(pre_current_tour, Lvertex);
                            if (best_found)
                            {
                                pre_current_tour = deep_copy(pos_current_tour);
                                i = 0;
                                //update
                                if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                {
                                    Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                    //Console.WriteLine("Population.best_TRP");
                                    //Console.WriteLine(Population.best_TRP);
                                }
                            }
                        }
                        else
                        {
                            if (i == 3)
                            {
                                //Console.WriteLine("improve_greedy_two_opt_TRP");
                                pos_current_tour = second_or_TRP(pre_current_tour, Lvertex);
                                if (best_found)
                                {
                                    pre_current_tour = deep_copy(pos_current_tour);
                                    i = 0;
                                    //update
                                    if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                    {
                                        Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                        //Console.WriteLine("Population.best_TRP");
                                        //Console.WriteLine(Population.best_TRP);
                                    }
                                }
                            }
                            else
                            {

                                if (i == 4)
                                {
                                    //Console.WriteLine("improve_greedy_two_opt_TRP");
                                    pos_current_tour = improve_greedy_two_opt_TRP(pre_current_tour, Lvertex);
                                    if (best_found)
                                    {
                                        pre_current_tour = deep_copy(pos_current_tour);
                                        i = 0;
                                        //update
                                        if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                        {
                                            Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                            //Console.WriteLine("Population.best_TRP");
                                            //Console.WriteLine(Population.best_TRP);
                                        }
                                    }
                                }
                                else
                                {
                                    //Console.WriteLine("greedy_three_edge_opt_Case_2");
                                    pos_current_tour = second_or_TRP(pre_current_tour, Lvertex);
                                    if (best_found)
                                    {
                                        pre_current_tour = deep_copy(pos_current_tour);
                                        i = 0;
                                        //update
                                        if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                        {
                                            Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                            //Console.WriteLine("Population.best_TRP");
                                            //Console.WriteLine(Population.best_TRP);
                                        }
                                    }
                                }
                            }

                        }
                    }
                }
            }
            return pre_current_tour;
        }

        public Tour improved_VND_TRP(Tour current_tour, double current_latency, ArrayList Lvertex, Random rand, int k, int neighborhood_Restriction, int l)
        {
            Tour pre_current_tour = new Tour();

            pre_current_tour = deep_copy(current_tour);

            for (int i = 0; i < 5; i++)
            {
                best_found = false;
                //write_file(namefile); write_file_1(namefile);
                Tour pos_current_tour = new Tour();
                if (i == 0)
                {
                    //Console.WriteLine("swap_adjacent");
                    pos_current_tour = swap_adjacent_TRP(pre_current_tour, Lvertex);
                    if (best_found)
                    {
                        pre_current_tour = deep_copy(pos_current_tour);
                        i = 0;
                        //print(pre_current_tour);
                        //update
                        if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                        {
                            Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                            //Console.WriteLine("Population.best_TSP");
                            //Console.WriteLine(Population.best_TSP);
                        }
                        if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                        {
                            Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                            //Console.WriteLine("Population.best_TRP");
                            //Console.WriteLine(Population.best_TRP);
                        }
                    }
                }
                else
                {
                    if (i == 1)
                    {
                        //Console.WriteLine("remove_insert");
                        pos_current_tour = remove_insert_TRP(pre_current_tour, Lvertex);
                        if (best_found)
                        {
                            pre_current_tour = deep_copy(pos_current_tour);
                            i = 0;
                            //print(pre_current_tour);
                            //Console.ReadKey();
                            //update
                            if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                            {
                                Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                //Console.WriteLine("Population.best_TSP");
                                //Console.WriteLine(Population.best_TSP);
                            }
                            if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                            {
                                Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                //Console.WriteLine("Population.best_TRP");
                                //Console.WriteLine(Population.best_TRP);
                            }
                        }
                    }
                    else
                    {
                        if (i == 2)
                        {
                            //Console.WriteLine("move_up_full");
                            pos_current_tour = swap_TRP(pre_current_tour, Lvertex);
                            if (best_found)
                            {
                                pre_current_tour = deep_copy(pos_current_tour);
                                i = 0;
                                //update
                                if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                {
                                    Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                    //Console.WriteLine("Population.best_TSP");
                                    //Console.WriteLine(Population.best_TSP);
                                }
                                if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                {
                                    Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                    //Console.WriteLine("Population.best_TRP");
                                    //Console.WriteLine(Population.best_TRP);
                                }
                            }
                        }
                        else
                        {
                            if (i == 3)
                            {
                                //Console.WriteLine("improve_greedy_two_opt");
                                pos_current_tour = improve_greedy_two_opt_TRP(pre_current_tour, Lvertex);
                                if (best_found)
                                {
                                    pre_current_tour = deep_copy(pos_current_tour);
                                    i = 0;
                                    //update
                                    if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                    {
                                        Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                        //Console.WriteLine("Population.best_TSP");
                                        //Console.WriteLine(Population.best_TSP);
                                    }
                                    if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                    {
                                        Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                        //Console.WriteLine("Population.best_TRP");
                                        //Console.WriteLine(Population.best_TRP);
                                    }
                                }
                            }
                            else
                            {

                                if (i == 4)
                                {
                                    //Console.WriteLine("greedy_three_edge_opt_Case_1");
                                    pos_current_tour = full_first_or_TRP(pre_current_tour, Lvertex);
                                    if (best_found)
                                    {
                                        pre_current_tour = deep_copy(pos_current_tour);
                                        i = 0;
                                        //update
                                        if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                        {
                                            Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                            //Console.WriteLine("Population.best_TSP");
                                            //Console.WriteLine(Population.best_TSP);
                                        }
                                        if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                        {
                                            Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                            //Console.WriteLine("Population.best_TRP");
                                            //Console.WriteLine(Population.best_TRP);
                                        }
                                    }
                                }
                                else
                                {

                                    if (i == 5)
                                    {
                                        //Console.WriteLine("greedy_three_edge_opt_Case_2");
                                        pos_current_tour = second_or_TRP(pre_current_tour, Lvertex);
                                        if (best_found)
                                        {
                                            pre_current_tour = deep_copy(pos_current_tour);
                                            i = 0;
                                            //update
                                            if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                            {
                                                Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                                //Console.WriteLine("Population.best_TSP");
                                                //Console.WriteLine(Population.best_TSP);
                                            }
                                            if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                            {
                                                Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                                //Console.WriteLine("Population.best_TRP");
                                                //Console.WriteLine(Population.best_TRP);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        pos_current_tour = greedy_three_edge_opt_Case_1(pre_current_tour, Lvertex);
                                        if (best_found)
                                        {
                                            pre_current_tour = deep_copy(pos_current_tour);
                                            i = 0;
                                            //update
                                            if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                            {
                                                Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                                //Console.WriteLine("Population.best_TSP");
                                                //Console.WriteLine(Population.best_TSP);
                                            }
                                            if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                            {
                                                Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                                //Console.WriteLine("Population.best_TRP");
                                                //Console.WriteLine(Population.best_TRP);
                                            }
                                        }
                                    }
                                }

                            }

                        }
                    }
                }
            }
            return pre_current_tour;
        }

        public Tour light_improved_VND_TSP(Tour current_tour, double current_latency, ArrayList Lvertex, Random rand, int k, int neighborhood_Restriction, int l)
        {
            Tour pre_current_tour = new Tour();

            pre_current_tour = deep_copy(current_tour);

            for (int i = 0; i < 6; i++)
            {
                best_found = false;
                //write_file(namefile); write_file_1(namefile);
                Tour pos_current_tour = new Tour();
                if (i == 0)
                {
                    //Console.WriteLine("swap_TSP");
                    pos_current_tour = swap_TSP(pre_current_tour, Lvertex);
                    if (best_found)
                    {
                        pre_current_tour = deep_copy(pos_current_tour);
                        i = 0;
                        //print(pre_current_tour);
                        //update
                        if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                        {
                            Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                            Console.WriteLine("Population.best_TSP");
                            Console.WriteLine(Population.best_TSP);
                        }
                    }
                }
                else
                {
                    if (i == 1)
                    {
                        //Console.WriteLine("remove_insert");
                        pos_current_tour = remove_insert_TSP(pre_current_tour, Lvertex);
                        if (best_found)
                        {
                            pre_current_tour = deep_copy(pos_current_tour);
                            i = 0;
                            //print(pre_current_tour);
                            //Console.ReadKey();
                            //update
                            if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                            {
                                Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                Console.WriteLine("Population.best_TSP");
                                Console.WriteLine(Population.best_TSP);
                            }
                        }
                    }
                    else
                    {

                        if (i == 2)
                        {
                            //Console.WriteLine("first_or_TRP");
                            pos_current_tour = first_or_TSP(pre_current_tour, Lvertex);
                            if (best_found)
                            {
                                pre_current_tour = deep_copy(pos_current_tour);
                                i = 0;
                                //update
                                if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                {
                                    Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                    Console.WriteLine("Population.best_TSP");
                                    Console.WriteLine(Population.best_TSP);
                                }
                            }
                        }
                        else
                        {
                            if (i == 3)
                            {
                                //Console.WriteLine("second_or_TSP");
                                pos_current_tour = second_or_TSP(pre_current_tour, Lvertex);
                                //pos_current_tour = first_or_TSP(pre_current_tour, Lvertex);

                                if (best_found)
                                {
                                    pre_current_tour = deep_copy(pos_current_tour);
                                    i = 0;
                                    //update
                                    if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                    {
                                        Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                        Console.WriteLine("Population.best_TSP");
                                        Console.WriteLine(Population.best_TSP);
                                    }
                                }
                            }
                            else
                            {

                                if (i == 4)
                                {
                                    //Console.WriteLine("greedy_three_edge_opt_Case_1");
                                    pos_current_tour = improve_greedy_two_opt_TSP(pre_current_tour, Lvertex);
                                    if (best_found)
                                    {
                                        pre_current_tour = deep_copy(pos_current_tour);
                                        i = 0;
                                        //update
                                        if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                        {
                                            Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                            Console.WriteLine("Population.best_TSP");
                                            Console.WriteLine(Population.best_TSP);
                                        }
                                    }
                                }
                                else
                                {
                                    //Console.WriteLine("greedy_three_edge_opt_Case_2");
                                    pos_current_tour = second_or_TSP(pre_current_tour, Lvertex);
                                    if (best_found)
                                    {
                                        pre_current_tour = deep_copy(pos_current_tour);
                                        i = 0;
                                        //update
                                        if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                        {
                                            Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                            Console.WriteLine("Population.best_TSP");
                                            Console.WriteLine(Population.best_TSP);
                                        }
                                    }
                                }

                            }
                        }
                    }

                }
            }
            return pre_current_tour;
        }

        public Tour improved_VND_TSP(Tour current_tour, double current_latency, ArrayList Lvertex, Random rand, int k, int neighborhood_Restriction, int l)
        {
            Tour pre_current_tour = new Tour();

            pre_current_tour = deep_copy(current_tour);

            for (int i = 0; i < 5; i++)
            {
                best_found = false;
                //write_file(namefile); write_file_1(namefile);
                Tour pos_current_tour = new Tour();
                if (i == 0)
                {
                    //Console.WriteLine("swap_adjacent");
                    pos_current_tour = swap_TSP(pre_current_tour, Lvertex);
                    if (best_found)
                    {
                        pre_current_tour = deep_copy(pos_current_tour);
                        i = 0;
                        //print(pre_current_tour);
                        //update
                        if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                        {
                            Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                            Console.WriteLine("Population.best_TSP");
                            Console.WriteLine(Population.best_TSP);
                        }
                        if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                        {
                            Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                            Console.WriteLine("Population.best_TRP");
                            Console.WriteLine(Population.best_TRP);
                        }
                    }
                }
                else
                {
                    if (i == 1)
                    {
                        //Console.WriteLine("remove_insert");
                        pos_current_tour = remove_insert_TSP(pre_current_tour, Lvertex);
                        if (best_found)
                        {
                            pre_current_tour = deep_copy(pos_current_tour);
                            i = 0;
                            //print(pre_current_tour);
                            //Console.ReadKey();
                            //update
                            if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                            {
                                Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                Console.WriteLine("Population.best_TSP");
                                Console.WriteLine(Population.best_TSP);
                            }
                            if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                            {
                                Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                Console.WriteLine("Population.best_TRP");
                                Console.WriteLine(Population.best_TRP);
                            }
                        }
                    }
                    else
                    {

                        if (i == 2)
                        {
                            //Console.WriteLine("move_up_full");
                            pos_current_tour = first_or_TSP(pre_current_tour, Lvertex);
                            if (best_found)
                            {
                                pre_current_tour = deep_copy(pos_current_tour);
                                i = 0;
                                //update
                                if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                {
                                    Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                    Console.WriteLine("Population.best_TSP");
                                    Console.WriteLine(Population.best_TSP);
                                }
                                if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                {
                                    Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                    Console.WriteLine("Population.best_TRP");
                                    Console.WriteLine(Population.best_TRP);
                                }
                            }
                        }
                        else
                        {
                            if (i == 3)
                            {
                                //Console.WriteLine("second_or_TSP");
                                pos_current_tour = second_or_TSP(pre_current_tour, Lvertex);
                                //pos_current_tour = first_or_TSP(pre_current_tour, Lvertex);

                                if (best_found)
                                {
                                    pre_current_tour = deep_copy(pos_current_tour);
                                    i = 0;
                                    //update
                                    if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                    {
                                        Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                        Console.WriteLine("Population.best_TSP");
                                        Console.WriteLine(Population.best_TSP);
                                    }
                                    if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                    {
                                        Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                        Console.WriteLine("Population.best_TRP");
                                        Console.WriteLine(Population.best_TRP);
                                    }
                                }
                            }
                            else
                            {

                                if (i == 4)
                                {
                                    //Console.WriteLine("improve_greedy_two_opt_TSP");
                                    pos_current_tour = improve_greedy_two_opt_TSP(pre_current_tour, Lvertex);
                                    if (best_found)
                                    {
                                        pre_current_tour = deep_copy(pos_current_tour);
                                        i = 0;
                                        //update
                                        if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                        {
                                            Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                            Console.WriteLine("Population.best_TSP");
                                            Console.WriteLine(Population.best_TSP);
                                        }
                                        if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                        {
                                            Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                            Console.WriteLine("Population.best_TRP");
                                            Console.WriteLine(Population.best_TRP);
                                        }
                                    }
                                }
                                else
                                {

                                    if (i == 5)
                                    {
                                        //Console.WriteLine("second_or_TSP");
                                        pos_current_tour = second_or_TSP(pre_current_tour, Lvertex);
                                        if (best_found)
                                        {
                                            pre_current_tour = deep_copy(pos_current_tour);
                                            i = 0;
                                            //update
                                            if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                            {
                                                Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                                Console.WriteLine("Population.best_TSP");
                                                Console.WriteLine(Population.best_TSP);
                                            }
                                            if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                            {
                                                Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                                Console.WriteLine("Population.best_TRP");
                                                Console.WriteLine(Population.best_TRP);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        pos_current_tour = greedy_three_edge_opt_Case_1(pre_current_tour, Lvertex);
                                        if (best_found)
                                        {
                                            pre_current_tour = deep_copy(pos_current_tour);
                                            i = 0;
                                            //update
                                            if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                            {
                                                Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                                Console.WriteLine("Population.best_TSP");
                                                Console.WriteLine(Population.best_TSP);
                                            }
                                            if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                            {
                                                Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                                Console.WriteLine("Population.best_TRP");
                                                Console.WriteLine(Population.best_TRP);
                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }

                }
            }
            return pre_current_tour;
        }

        public Tour swap_adjacent_TSP(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);
            int i, j;

            //local_latency = 0;
            bool improve = true;
            if (tour_current.Ltour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;
                    while (i < tour_current.Ltour.Count - 1)
                    {
                        int t;
                        j = i + 1;

                        double orgin_length = (double)tour_current.fac_cost[0];
                        double orgin_latency = (double)tour_current.fac_cost[1];
                        tour_current = (Tour)clear_tour(tour_current);

                        double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                        //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);
                        tour_current.fac_cost.Add(double.MaxValue);
                        //Console.WriteLine("local_length");
                        //Console.WriteLine(local_length);
                        //Console.WriteLine("local_latency");
                        //Console.WriteLine(local_latency);


                        //t = (int)tour_current.Ltour[i];
                        //tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                        //tour_current.Ltour[j] = (int)t;

                        //tour_current = (Tour)clear_tour(tour_current);
                        //double length = tour_current.Calculate_fac_TSP(Lvertex);
                        //Console.ReadKey();

                        //if ((Math.Round(length) != Math.Round(local_length)) || (Math.Round(latency) != Math.Round(local_latency)))
                        //{
                        //    Console.WriteLine("error");
                        //    Console.ReadKey();
                        //}
                        if (local_length < (double) initial_tour.fac_cost[0])
                        {
                            //tour_current = deep_copy(initial_tour);
                            //Console.WriteLine(initial_tour.fac_cost[0]);
                            //Console.WriteLine(tour_current.fac_cost[0]);
                            t = (int)tour_current.Ltour[i];
                            tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                            tour_current.Ltour[j] = (int)t;

                            //tour_current = (Tour)clear_tour(tour_current);
                            //tour_current.Calculate_fac_TSP(Lvertex);
                            //tour_current.Calculate_fac_TRP(Lvertex);
                            //Console.ReadKey();
                            //
                            initial_tour = deep_copy(tour_current);
                            improve = true;
                            best_found = true;

                            //Console.WriteLine(initial_tour.fac_cost[0]);
                            //Console.WriteLine(initial_tour.fac_cost[1]);
                            //Console.ReadKey();
                        }
                        else
                        {
                            tour_current = deep_copy(initial_tour);
                        }
                        if (improve == true) break;
                        else
                            i++;
                        //Console.WriteLine(i);
                    }

                }
            }
            return initial_tour;
        }
        public Tour swap_adjacent_TRP(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);
            int i, j;

            //local_latency = 0;
            bool improve = true;
            if (tour_current.Ltour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;
                    while (i < tour_current.Ltour.Count - 1)
                    {
                        int t;
                        j = i + 1;

                        double orgin_length = (double)tour_current.fac_cost[0];
                        double orgin_latency = (double)tour_current.fac_cost[1];
                        tour_current = (Tour)clear_tour(tour_current);

                        //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                        tour_current.fac_cost.Add(double.MaxValue);
                        double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                        //Console.WriteLine("local_length");
                        //Console.WriteLine(local_length);
                        //Console.WriteLine("local_latency");
                        //Console.WriteLine(local_latency);


                        //t = (int)tour_current.Ltour[i];
                        ///tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                        //tour_current.Ltour[j] = (int)t;

                        //tour_current = (Tour)clear_tour(tour_current);
                        //double length = tour_current.Calculate_fac_TSP(Lvertex);
                        //double latency = tour_current.Calculate_fac_TRP(Lvertex);
                        //Console.WriteLine(length);

                        //Console.WriteLine(latency);
                        //Console.ReadKey();

                        //if ((Math.Round(length) != Math.Round(local_length)) || (Math.Round(latency) != Math.Round(local_latency)))
                        //{
                        //    Console.WriteLine("error");
                        //    Console.ReadKey();
                        //}
                        if (local_latency < (double)initial_tour.fac_cost[1])
                        {
                            //tour_current = deep_copy(initial_tour);
                            //Console.WriteLine(initial_tour.fac_cost[0]);
                            //Console.WriteLine(tour_current.fac_cost[0]);
                            t = (int)tour_current.Ltour[i];
                            tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                            tour_current.Ltour[j] = (int)t;

                            //tour_current = (Tour)clear_tour(tour_current);
                            //tour_current.Calculate_fac_TSP(Lvertex);
                            //tour_current.Calculate_fac_TRP(Lvertex);
                            //Console.ReadKey();
                            //
                            initial_tour = deep_copy(tour_current);
                            improve = true;
                            best_found = true;

                            //Console.WriteLine(initial_tour.fac_cost[0]);
                            //Console.WriteLine(initial_tour.fac_cost[1]);
                            //Console.ReadKey();
                        }
                        else
                        {
                            tour_current = deep_copy(initial_tour);
                        }
                        if (improve == true) break;
                        else
                            i++;
                        //Console.WriteLine(i);
                    }

                }
            }
            return initial_tour;
        }

        public Tour remove_insert_TSP(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            int i;
            bool improve = true;
            if (initial_tour.Ltour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;
                    while (i < tour_current.Ltour.Count - 1)
                    {
                        //Console.WriteLine("FASLEELFLFLFLFLFLFLLFFL");
                        //Console.ReadKey();
                        int num = (int)tour_current.Ltour[i];
                        tour_current.Ltour.Remove(num);
                        tour_current.Ltour.Add(num);

                        tour_current = (Tour)clear_tour(tour_current);
                        double local_length = tour_current.Calculate_fac_TSP(Lvertex);
                        //tour_current.Calculate_fac_TRP(Lvertex);
                        //tour_current.fac_cost.Add(double.MaxValue);
                        //tour_current.check_sol(tour_current.Ltour);
                        //Console.WriteLine(tour_current.fea);

                        if ((local_length < (double)initial_tour.fac_cost[0])&&(tour_current.fea==true))
                        {
                            initial_tour = deep_copy(tour_current);
                            improve = true;
                            best_found = true;
                        }
                        else
                        {
                            tour_current = deep_copy(initial_tour);
                        }
                        if (improve == true) break;
                        else
                            i++;
                    }
                }
            }
            return (initial_tour);
        }

        public Tour remove_insert_TRP(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            int i;
            bool improve = true;
            if (initial_tour.Ltour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;
                    while (i < tour_current.Ltour.Count - 1)
                    {
                        //Console.WriteLine("FASLEELFLFLFLFLFLFLLFFL");
                        //Console.ReadKey();
                        int num = (int)tour_current.Ltour[i];
                        tour_current.Ltour.Remove(num);
                        tour_current.Ltour.Add(num);

                        tour_current = (Tour)clear_tour(tour_current);
                        //tour_current.Calculate_fac_TSP(Lvertex);
                        tour_current.fac_cost.Add(double.MaxValue);
                        double local_latency = tour_current.Calculate_fac_TRP(Lvertex);
                        //tour_current.check_sol(tour_current.Ltour);
                        //Console.WriteLine(tour_current.fea);

                        if ((local_latency  < (double)initial_tour.fac_cost[1])&&(tour_current.fea==true))
                        {
                            initial_tour = deep_copy(tour_current);
                            improve = true;
                            best_found = true;
                        }
                        else
                        {
                            tour_current = deep_copy(initial_tour);
                        }
                        if (improve == true) break;
                        else
                            i++;
                    }
                }
            }
            return (initial_tour);
        }

        public Tour move_one_TSP(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);
            int i, j;

            if (initial_tour.Ltour.Count >= 3)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 1)
                {
                    j = i + 1;

                    int t;

                    double orgin_length = (double)tour_current.fac_cost[0];
                    double orgin_latency = (double)tour_current.fac_cost[1];
                    tour_current = (Tour)clear_tour(tour_current);

                    double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                    //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);
                    tour_current.fac_cost.Add(double.MaxValue);

                    //t = (int)tour_current.Ltour[i];
                    //tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                    //tour_current.Ltour[j] = (int)t;

                    //tour_current = (Tour)clear_tour(tour_current);
                    //tour_current.Calculate_fac_TSP(Lvertex);
                    //tour_current.Calculate_fac_TRP(Lvertex);

                    //Console.WriteLine("local_latency");
                    //Console.WriteLine(local_latency);
                    //Console.WriteLine("local_length");
                    //Console.WriteLine(local_length);


                    //t = (int)tour_current.Ltour[i];
                    //tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                    //tour_current.Ltour[j] = (int)t;

                    //tour_current = (Tour)clear_tour(tour_current);
                    //tour_current.Calculate_fac_TSP(Lvertex);
                    //tour_current.Calculate_fac_TRP(Lvertex);

                    //Console.WriteLine("local_latency");
                    //Console.ReadKey();

                    if (local_length < (double)initial_tour.fac_cost[0])
                    {

                        t = (int)tour_current.Ltour[i];
                        tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                        tour_current.Ltour[j] = (int)t;

                        initial_tour = deep_copy(tour_current);
                        best_found = true;
                    }
                    else
                    {
                        tour_current = deep_copy(initial_tour);
                    }
                    i++;
                }

            }
            return (tour_current);
        }
        public Tour move_one_TRP(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);
            int i, j;

            if (initial_tour.Ltour.Count >= 3)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 1)
                {
                    j = i + 1;

                    int t;

                    double orgin_length = (double)tour_current.fac_cost[0];
                    double orgin_latency = (double)tour_current.fac_cost[1];
                    tour_current = (Tour)clear_tour(tour_current);

                    //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                    tour_current.fac_cost.Add(double.MaxValue);

                    double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                    //t = (int)tour_current.Ltour[i];
                    //tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                    //tour_current.Ltour[j] = (int)t;

                    //tour_current = (Tour)clear_tour(tour_current);
                    //tour_current.Calculate_fac_TSP(Lvertex);
                    //tour_current.Calculate_fac_TRP(Lvertex);

                    //Console.WriteLine("local_latency");
                    //Console.WriteLine(local_latency);
                    //Console.WriteLine("local_length");
                    //Console.WriteLine(local_length);


                    //t = (int)tour_current.Ltour[i];
                    //tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                    //tour_current.Ltour[j] = (int)t;

                    //tour_current = (Tour)clear_tour(tour_current);
                    //tour_current.Calculate_fac_TSP(Lvertex);
                    //tour_current.Calculate_fac_TRP(Lvertex);

                    //Console.WriteLine("local_latency");
                    //Console.ReadKey();

                    if (local_latency < (double)initial_tour.fac_cost[1])
                    {

                        t = (int)tour_current.Ltour[i];
                        tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                        tour_current.Ltour[j] = (int)t;

                        initial_tour = deep_copy(tour_current);
                        best_found = true;
                    }
                    else
                    {
                        tour_current = deep_copy(initial_tour);
                    }
                    i++;
                }

            }
            return (tour_current);
        }

        public Tour swap_TSP(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            //Console.WriteLine("tour_current.Ltour.Count");
            ///Console.WriteLine(tour_current.Ltour.Count);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 2)
                {
                    j = i + 1;
                    while (j < tour_current.Ltour.Count - 1)
                    {
                        int t;
                        //Console.WriteLine("hello");

                        //double orgin_length = (double)tour_current.fac_cost[0];
                        //double orgin_latency = (double)tour_current.fac_cost[1];

                        //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                        //tour_current.fac_cost.Add(double.MaxValue);

                        //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);


                        //Console.WriteLine("local_latency");
                        //Console.WriteLine(local_length_1);
                        //Console.WriteLine("local_length");
                        //Console.WriteLine(local_latency_1);

                        //tour_current = deep_copy(initial_tour);

                        t = (int)tour_current.Ltour[j];
                        tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                        tour_current.Ltour[i] = (int)t;

                        tour_current = (Tour)clear_tour(tour_current);
                        double local_length = tour_current.Calculate_fac_TSP(Lvertex);
                        //t = (int)tour_current.Ltour[j];
                        //tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                        //tour_current.Ltour[k] = (int)t;

                        //tour_current = (Tour)clear_tour(tour_current);
                        //tour_current.Calculate_fac_TSP(Lvertex);
                        //tour_current.Calculate_fac_TRP(Lvertex);
                        //Console.ReadKey();

                        if ((local_length < (double)initial_tour.fac_cost[0]) && (tour_current.fea==true))
                        {
                            initial_tour = deep_copy(tour_current);
                            best_found = true;
                        }
                        else
                        {
                            //t = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                            //tour_current.Ltour[i] = (int)t;
                            tour_current = deep_copy(initial_tour);
                        }
                        j++;
                    }
                    i++;
                }
            }

            return initial_tour;
        }
        public Tour swap_TRP(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 2)
                {
                    j = i + 1;
                    while (j < tour_current.Ltour.Count - 1)
                    {
                        int t;

                        //double orgin_length = (double)tour_current.fac_cost[0];
                        //double orgin_latency = (double)tour_current.fac_cost[1];
                        //tour_current = (Tour)clear_tour(tour_current);

                        ////double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                        //tour_current.fac_cost.Add(double.MaxValue);
                        //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);


                        //Console.WriteLine("local_latency");
                        //Console.WriteLine(local_length_1);
                        //Console.WriteLine("local_length");
                        //Console.WriteLine(local_latency_1);

                        //tour_current = deep_copy(initial_tour);

                        t = (int)tour_current.Ltour[j];
                        tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                        tour_current.Ltour[i] = (int)t;

                        //t = (int)tour_current.Ltour[j];
                        //tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                        //tour_current.Ltour[k] = (int)t;

                        tour_current = (Tour)clear_tour(tour_current);
                        tour_current.fac_cost.Add(double.MaxValue);
                        double local_latency = tour_current.Calculate_fac_TRP(Lvertex);
                        //tour_current.Calculate_fac_TRP(Lvertex);
                        //Console.ReadKey();

                        if ((local_latency < (double)initial_tour.fac_cost[1])&&(tour_current.fea==true))
                        {
                            initial_tour = deep_copy(tour_current);
                            best_found = true;
                        }
                        else
                        {
                            //t = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                            //tour_current.Ltour[i] = (int)t;
                            tour_current = deep_copy(initial_tour);
                        }
                        j++;
                    }
                    i++;
                }
            }

            return initial_tour;
        }

        public Tour improve_greedy_two_opt_TRP(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);
            int i, j;

            //local_latency = 0;
            bool improve = true;
            if (initial_tour.Ltour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;

                    while (i < tour_current.Ltour.Count - 2)
                    {
                        j = i + 2;
                        while (j < tour_current.Ltour.Count)
                        {
                            int t;
                            //local_latency = (double)latency_tour_swap_edge(tour_current, Lvertex, i, j, fitness_before);
                            t = (int)tour_current.Ltour[i];

                            tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                            tour_current.Ltour[j] = (int)t;
                            tour_current.Ltour.Reverse(i, j - i + 1);

                            tour_current = (Tour)clear_tour(tour_current);
                            //tour_current.Calculate_fac_TSP(Lvertex);
                            tour_current.fac_cost.Add(double.MaxValue);
                            double local_latency = tour_current.Calculate_fac_TRP(Lvertex);

                            if ((local_latency < (double)initial_tour.fac_cost[1])&&(tour_current.fea==true))
                            {
                                initial_tour = deep_copy(tour_current);
                                improve = true;
                                best_found = true;
                            }
                            else
                            {
                                tour_current = deep_copy(initial_tour);
                            }
                            if (improve == true) break;
                            else j++;
                        }
                        if (improve == true) break;
                        else i++;
                    }
                }
            }
            return initial_tour;
        }

        public Tour improve_greedy_two_opt_TSP(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);
            int i, j;

            //local_latency = 0;
            bool improve = true;
            if (initial_tour.Ltour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;

                    while (i < tour_current.Ltour.Count - 2)
                    {
                        j = i + 2;
                        while (j < tour_current.Ltour.Count)
                        {
                            int t;
                            //local_latency = (double)latency_tour_swap_edge(tour_current, Lvertex, i, j, fitness_before);
                            t = (int)tour_current.Ltour[i];
                            tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                            tour_current.Ltour[j] = (int)t;
                            tour_current.Ltour.Reverse(i, j - i + 1);

                            tour_current = (Tour)clear_tour(tour_current);
                            double local_length = tour_current.Calculate_fac_TSP(Lvertex);
                            //tour_current.Calculate_fac_TRP(Lvertex);
                            //tour_current.fac_cost.Add(double.MaxValue);

                            if (((double)local_length < (double)initial_tour.fac_cost[0])&&(tour_current.fea==true))
                            {
                                initial_tour = deep_copy(tour_current);
                                improve = true;
                                best_found = true;
                            }
                            else
                            {
                                tour_current = deep_copy(initial_tour);
                            }
                            if (improve == true) break;
                            else j++;
                        }
                        if (improve == true) break;
                        else i++;
                    }
                }
            }
            return initial_tour;
        }

        public Tour full_first_or_TSP(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 2)
                {
                    j = i + 1;
                    while (j < tour_current.Ltour.Count - 1)
                    {
                        k = j + 1;
                        while (k < tour_current.Ltour.Count)
                        {
                            int t;

                            double orgin_length = (double)tour_current.fac_cost[0];
                            double orgin_latency = (double)tour_current.fac_cost[1];
                            tour_current = (Tour)clear_tour(tour_current);

                            double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                            double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                            t = (int)tour_current.Ltour[j];
                            tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                            tour_current.Ltour[i] = (int)t;

                            double orgin_length_1 = (double)tour_current.fac_cost[0];
                            double orgin_latency_1 = (double)tour_current.fac_cost[1];
                            tour_current = (Tour)clear_tour(tour_current);

                            double local_length_1 = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_length_1);
                            double local_latency_1 = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_latency_1);

                            //Console.WriteLine("local_latency");
                            //Console.WriteLine(local_length_1);
                            //Console.WriteLine("local_length");
                            //Console.WriteLine(local_latency_1);

                            //tour_current = deep_copy(initial_tour);

                            //t = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                            //tour_current.Ltour[i] = (int)t;

                            //t = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                            //tour_current.Ltour[k] = (int)t;

                            //tour_current = (Tour)clear_tour(tour_current);
                            //tour_current.Calculate_fac_TSP(Lvertex);
                            //tour_current.Calculate_fac_TRP(Lvertex);
                            //Console.ReadKey();

                            if ((double)local_length_1 < (double)initial_tour.fac_cost[0])
                            {
                                t = (int)tour_current.Ltour[j];
                                tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                                tour_current.Ltour[k] = (int)t;

                                initial_tour = deep_copy(tour_current);
                                best_found = true;
                            }
                            else
                            {
                                tour_current = deep_copy(initial_tour);
                            }
                            k++;
                        }
                        j++;
                    }
                    i++;
                }
            }

            return initial_tour;
        }


        public Tour full_first_or_TRP(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 2)
                {
                    j = i + 1;
                    while (j < tour_current.Ltour.Count - 1)
                    {
                        k = j + 1;
                        while (k < tour_current.Ltour.Count)
                        {
                            int t;

                            double orgin_length = (double)tour_current.fac_cost[0];
                            double orgin_latency = (double)tour_current.fac_cost[1];
                            tour_current = (Tour)clear_tour(tour_current);
                            
                            tour_current.fac_cost.Add(double.MaxValue);
                            //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                            double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                            t = (int)tour_current.Ltour[j];
                            tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                            tour_current.Ltour[i] = (int)t;

                            double orgin_length_1 = (double)tour_current.fac_cost[0];
                            double orgin_latency_1 = (double)tour_current.fac_cost[1];
                            tour_current = (Tour)clear_tour(tour_current);

                            tour_current.fac_cost.Add(double.MaxValue);
                            //double local_length_1 = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_length_1);
                            double local_latency_1 = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_latency_1);

                            //Console.WriteLine("local_latency");
                            //Console.WriteLine(local_length_1);
                            //Console.WriteLine("local_length");
                            //Console.WriteLine(local_latency_1);

                            //tour_current = deep_copy(initial_tour);

                            //t = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                            //tour_current.Ltour[i] = (int)t;

                            //t = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                            //tour_current.Ltour[k] = (int)t;

                            //tour_current = (Tour)clear_tour(tour_current);
                            //tour_current.Calculate_fac_TSP(Lvertex);
                            //tour_current.Calculate_fac_TRP(Lvertex);
                            //Console.ReadKey();

                            if ((double)local_latency_1 < (double)initial_tour.fac_cost[1])
                            {
                                t = (int)tour_current.Ltour[j];
                                tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                                tour_current.Ltour[k] = (int)t;

                                initial_tour = deep_copy(tour_current);
                                best_found = true;
                            }
                            else
                            {
                                tour_current = deep_copy(initial_tour);
                            }
                            k++;
                        }
                        j++;
                    }
                    i++;
                }
            }

            return initial_tour;
        }

        public Tour first_or_TSP(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 2)
                {
                    j = i + 1;
                    k = j + 1;
                    int t;

                    //double orgin_length = (double)tour_current.fac_cost[0];
                    //double orgin_latency = (double)tour_current.fac_cost[1];
                    //tour_current = (Tour)clear_tour(tour_current);

                    //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                    //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                    //t = (int)tour_current.Ltour[j];
                    //tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                    //tour_current.Ltour[i] = (int)t;

                    //double orgin_length_1 = (double)tour_current.fac_cost[0];
                    //double orgin_latency_1 = (double)tour_current.fac_cost[1];
                    //tour_current = (Tour)clear_tour(tour_current);

                    //double local_length_1 = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_length_1);
                    //double local_latency_1 = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_latency_1);

                    //Console.WriteLine("local_latency");
                    //Console.WriteLine(local_length_1);
                    //Console.WriteLine("local_length");
                    //Console.WriteLine(local_latency_1);

                    //tour_current = deep_copy(initial_tour);

                    t = (int)tour_current.Ltour[j];
                    tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                    tour_current.Ltour[i] = (int)t;

                    t = (int)tour_current.Ltour[j];
                    tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                    tour_current.Ltour[k] = (int)t;

                    tour_current = (Tour)clear_tour(tour_current);
                    double local_length = tour_current.Calculate_fac_TSP(Lvertex);
                    //tour_current.Calculate_fac_TRP(Lvertex);
                    //Console.ReadKey();

                    if (((double)local_length < (double)initial_tour.fac_cost[0])&&(tour_current.fea==true))
                    {
                        initial_tour = deep_copy(tour_current);
                        best_found = true;
                    }
                    else
                    {
                        tour_current = deep_copy(initial_tour);
                    }
                    i++;
                }
            }

            return initial_tour;
        }

        public Tour first_or_TRP(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 2)
                {
                    j = i + 1;
                    k = j + 1;
                    int t;

                    //double orgin_length = (double)tour_current.fac_cost[0];
                    //double orgin_latency = (double)tour_current.fac_cost[1];
                    tour_current = (Tour)clear_tour(tour_current);

                    //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                    //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                    //t = (int)tour_current.Ltour[j];
                    //tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                    //tour_current.Ltour[i] = (int)t;

                    //double orgin_length_1 = (double)tour_current.fac_cost[0];
                    //double orgin_latency_1 = (double)tour_current.fac_cost[1];
                    //tour_current = (Tour)clear_tour(tour_current);

                    //double local_length_1 = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_length_1);
                    //double local_latency_1 = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_latency_1);

                    //Console.WriteLine("local_latency");
                    //Console.WriteLine(local_length_1);
                    //Console.WriteLine("local_length");
                    //Console.WriteLine(local_latency_1);

                    //tour_current = deep_copy(initial_tour);

                    t = (int)tour_current.Ltour[j];
                    tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                    tour_current.Ltour[i] = (int)t;

                    t = (int)tour_current.Ltour[j];
                    tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                    tour_current.Ltour[k] = (int)t;

                    //tour_current = (Tour)clear_tour(tour_current);
                    tour_current.fac_cost.Add(double.MaxValue);
                    double local_length = tour_current.Calculate_fac_TRP(Lvertex);
                    //tour_current.Calculate_fac_TRP(Lvertex);
                    //Console.ReadKey();

                    if (((double)local_length < (double)initial_tour.fac_cost[1])&&(tour_current.fea ==true))
                    {
                        initial_tour = deep_copy(tour_current);
                        best_found = true;
                    }
                    else
                    {
                        tour_current = deep_copy(initial_tour);
                    }
                    i++;
                }
            }
            

            return initial_tour;
        }

        public Tour second_or_TSP(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 3)
                {
                    j = i + 1;
                    k = j + 1;
                    int t;

                    //double orgin_length = (double)tour_current.fac_cost[0];
                    //double orgin_latency = (double)tour_current.fac_cost[1];
                    //tour_current = (Tour)clear_tour(tour_current);

                    //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_length);
                    //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_latency);

                    //t = (int)tour_current.Ltour[j];
                    //tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                    //tour_current.Ltour[k] = (int)t;

                    //double orgin_length_1 = (double)tour_current.fac_cost[0];
                    //double orgin_latency_1 = (double)tour_current.fac_cost[1];
                    //tour_current = (Tour)clear_tour(tour_current);

                    //double local_length_1 = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length_1);
                    //double local_latency_1 = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency_1);

                    //Console.WriteLine("local_latency");
                    //Console.WriteLine(local_length_1);
                    //Console.WriteLine("local_length");
                    //Console.WriteLine(local_latency_1);

                    //tour_current = deep_copy(initial_tour);

                    t = (int)tour_current.Ltour[j];
                    tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                    tour_current.Ltour[k] = (int)t;

                    t = (int)tour_current.Ltour[j];
                    tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                    tour_current.Ltour[i] = (int)t;

                    tour_current = (Tour)clear_tour(tour_current);
                    double local_length =  tour_current.Calculate_fac_TSP(Lvertex);
                    //tour_current.Calculate_fac_TRP(Lvertex);
                    //Console.ReadKey();

                    if (((double)local_length < (double)initial_tour.fac_cost[0])&&(tour_current.fea==true))
                    {
                        initial_tour = deep_copy(tour_current);
                        best_found = true;
                    }
                    else
                    {
                        tour_current = deep_copy(initial_tour);
                    }
                    i++;
                }

            }

            return initial_tour;
        }

        public Tour second_or_TRP(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 3)
                {
                    j = i + 1;
                    k = j + 1;
                    int t;

                    //double orgin_length = (double)tour_current.fac_cost[0];
                    //double orgin_latency = (double)tour_current.fac_cost[1];
                    //tour_current = (Tour)clear_tour(tour_current);

                    //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_length);
                    //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_latency);

                    //t = (int)tour_current.Ltour[j];
                    //tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                    //tour_current.Ltour[k] = (int)t;

                    //double orgin_length_1 = (double)tour_current.fac_cost[0];
                    //double orgin_latency_1 = (double)tour_current.fac_cost[1];
                    //tour_current = (Tour)clear_tour(tour_current);

                    //double local_length_1 = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length_1);
                    //double local_latency_1 = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency_1);

                    //Console.WriteLine("local_latency");
                    //Console.WriteLine(local_length_1);
                    //Console.WriteLine("local_length");
                    //Console.WriteLine(local_latency_1);

                    //tour_current = deep_copy(initial_tour);

                    t = (int)tour_current.Ltour[j];
                    tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                    tour_current.Ltour[k] = (int)t;

                    t = (int)tour_current.Ltour[j];
                    tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                    tour_current.Ltour[i] = (int)t;

                    tour_current = (Tour)clear_tour(tour_current);
                    //tour_current.Calculate_fac_TSP(Lvertex);
                    tour_current.fac_cost.Add(double.MaxValue);
                    double local_latency = tour_current.Calculate_fac_TRP(Lvertex);
                    //Console.ReadKey();

                    if (((double)local_latency < (double)initial_tour.fac_cost[1])&&(tour_current.fea==true))
                    {
                        initial_tour = deep_copy(tour_current);
                        best_found = true;
                    }
                    else
                    {
                        tour_current = deep_copy(initial_tour);
                    }
                    i++;
                }
            }
            

            return initial_tour;
        }

        public Tour improved_VND(Tour current_tour, double current_latency, ArrayList Lvertex, Random rand, int k, int neighborhood_Restriction, int l)
        {
            Tour pre_current_tour = new Tour();

            pre_current_tour = deep_copy(current_tour);

            for (int i = 0; i < 7; i++)
            {
                best_found = false;
                //write_file(namefile); write_file_1(namefile);
                Tour pos_current_tour = new Tour();
                if (i == 0)
                {
                    //Console.WriteLine("swap_adjacent");
                    pos_current_tour = swap_adjacent(pre_current_tour, Lvertex);
                    if (best_found)
                    {
                        pre_current_tour = deep_copy(pos_current_tour);
                        i = 0;
                        //print(pre_current_tour);
                        //update
                        if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                        {
                            Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                            //Console.WriteLine("Population.best_TSP");
                            //Console.WriteLine(Population.best_TSP);
                        }
                        if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                        {
                            Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                            //Console.WriteLine("Population.best_TRP");
                            //Console.WriteLine(Population.best_TRP);
                        }
                    }
                }
                else 
                { 
                    if (i == 1)
                    {
                        //Console.WriteLine("remove_insert");
                        pos_current_tour = remove_insert(pre_current_tour, Lvertex);
                        if (best_found)
                        {
                            pre_current_tour = deep_copy(pos_current_tour);
                            i = 0;
                            //print(pre_current_tour);
                            //Console.ReadKey();
                            //update
                            if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                            {
                                Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                //Console.WriteLine("Population.best_TSP");
                                //Console.WriteLine(Population.best_TSP);
                            }
                            if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                            {
                                Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                //Console.WriteLine("Population.best_TRP");
                                //Console.WriteLine(Population.best_TRP);
                            }
                        }
                    }
                    else
                    {
                        if (i == 2)
                        {
                            //Console.WriteLine("move_down_full");
                            pos_current_tour = move_one(pre_current_tour, Lvertex);
                            if (best_found)
                            {
                                pre_current_tour = deep_copy(pos_current_tour);
                                i = 0;
                                //update
                                if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                {
                                    Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                    //Console.WriteLine("Population.best_TSP");
                                    //Console.WriteLine(Population.best_TSP);
                                }
                                if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                {
                                    Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                    //Console.WriteLine("Population.best_TRP");
                                    //Console.WriteLine(Population.best_TRP);
                                }
                            }
                        }
                        else
                        {
                            if (i == 3)
                            {
                                //Console.WriteLine("move_up_full");
                                pos_current_tour = swap(pre_current_tour, Lvertex);
                                if (best_found)
                                {
                                    pre_current_tour = deep_copy(pos_current_tour);
                                    i = 0;
                                    //update
                                    if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                    {
                                        Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                        //Console.WriteLine("Population.best_TSP");
                                        //Console.WriteLine(Population.best_TSP);
                                    }
                                    if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                    {
                                        Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                        //Console.WriteLine("Population.best_TRP");
                                        //Console.WriteLine(Population.best_TRP);
                                    }
                                }
                            }
                            else
                            {
                                if (i == 4)
                                {
                                    //Console.WriteLine("improve_greedy_two_opt");
                                    pos_current_tour = improve_greedy_two_opt(pre_current_tour, Lvertex);
                                    if (best_found)
                                    {
                                        pre_current_tour = deep_copy(pos_current_tour);
                                        i = 0;
                                        //update
                                        if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                        {
                                            Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                            //Console.WriteLine("Population.best_TSP");
                                            //Console.WriteLine(Population.best_TSP);
                                        }
                                        if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                        {
                                            Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                            //Console.WriteLine("Population.best_TRP");
                                            //Console.WriteLine(Population.best_TRP);
                                        }
                                    }
                                }
                                else
                                {

                                    if (i == 5)
                                    {
                                        //Console.WriteLine("greedy_three_edge_opt_Case_1");
                                        pos_current_tour = first_or(pre_current_tour, Lvertex);
                                        if (best_found)
                                        {
                                            pre_current_tour = deep_copy(pos_current_tour);
                                            i = 0;
                                            //update
                                            if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                            {
                                                Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                                //Console.WriteLine("Population.best_TSP");
                                                //Console.WriteLine(Population.best_TSP);
                                            }
                                            if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                            {
                                                Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                                //Console.WriteLine("Population.best_TRP");
                                                //Console.WriteLine(Population.best_TRP);
                                            }
                                        }
                                    }
                                    else
                                    {

                                        if (i == 6)
                                        {
                                            //Console.WriteLine("greedy_three_edge_opt_Case_2");
                                            pos_current_tour = second_or(pre_current_tour, Lvertex);
                                            if (best_found)
                                            {
                                                pre_current_tour = deep_copy(pos_current_tour);
                                                i = 0;
                                                //update
                                                if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                                {
                                                    Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                                    //Console.WriteLine("Population.best_TSP");
                                                    //Console.WriteLine(Population.best_TSP);
                                                }
                                                if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                                {
                                                    Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                                    //Console.WriteLine("Population.best_TRP");
                                                    //Console.WriteLine(Population.best_TRP);
                                                }
                                            }
                                        }
                                        else
                                        {
                                            pos_current_tour = greedy_three_edge_opt_Case_1(pre_current_tour, Lvertex);
                                            if (best_found)
                                            {
                                                pre_current_tour = deep_copy(pos_current_tour);
                                                i = 0;
                                                //update
                                                if ((double)pre_current_tour.fac_cost[0] < (double)Population.best_TSP)
                                                {
                                                    Population.best_TSP = (double)pre_current_tour.fac_cost[0];
                                                    //Console.WriteLine("Population.best_TSP");
                                                    //Console.WriteLine(Population.best_TSP);
                                                }
                                                if ((double)pre_current_tour.fac_cost[1] < (double)Population.best_TRP)
                                                {
                                                    Population.best_TRP = (double)pre_current_tour.fac_cost[1];
                                                    //Console.WriteLine("Population.best_TRP");
                                                    //Console.WriteLine(Population.best_TRP);
                                                }
                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }
            return pre_current_tour;
        }

        public void print(Tour tour)
        {
            string name = "population1-" + ".txt";
            StreamWriter sr = new StreamWriter(name, false);

            try
            {
                string line = "";

                Console.WriteLine("k_vehicle");
                Console.WriteLine(tour.Ltour.Count);

                for (int j = 0; j < tour.Ltour.Count; j++)
                {
                    line = line + " " + tour.Ltour[j].ToString();
                }
                sr.WriteLine(line + "----" + tour.fac_cost[0] + "---" + tour.fac_cost[1]);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            sr.Close();
        }

        public Tour simple_swap_mutation(Tour initial_tour, ArrayList Lvertex, Random rand, int diversity_value)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            int i, j, k;

            for (k = 0; k < diversity_value; k++)
            {
                do
                {
                    i = rand.Next(tour_current.Ltour.Count);

                } while (i <= 0);

                do
                {
                    j = rand.Next(tour_current.Ltour.Count);

                } while ((j <= 0) || (i == j));


                int t = (int)tour_current.Ltour[i];
                tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                tour_current.Ltour[j] = t;
            }
            return (tour_current);
        }

        public Tour clear_tour(Tour T)
        {

            T.fac_cost.Clear();
            T.rank = -1;
            T.sub_rank.Clear();
            T.skill_factor = -1;
            T.scalar_fitness = -1;
            T.fea = false;
            return T;
        }

        public Tour deep_copy(Tour T)
        {
            Tour pos_T = new Tour();

            pos_T.fac_cost = (ArrayList)T.fac_cost.Clone();
            pos_T.sub_rank = (ArrayList)T.sub_rank.Clone();
            pos_T.skill_factor = (double)T.skill_factor;
            pos_T.scalar_fitness = (double)T.scalar_fitness;
            pos_T.rank = (int) T.rank;
            pos_T.Ltour = (ArrayList)T.Ltour.Clone();
            pos_T.fea = T.fea;
            return pos_T;
        }

        //public int compare(Tour T1, Tour T2)
        //{
        //    Population population = new Population();
        //    Tour pos_T1 = new Tour();
        //    Tour pos_T2 = new Tour();
        //    pos_T1 = deep_copy(T1);
        //    pos_T2 = deep_copy(T2);

        //    population.Add(pos_T1);
        //    population.Add(pos_T2);
        //    population.Rank_population();
        //    if((int) ((Tour)pos_T1).rank > (int)((Tour)pos_T2).rank)
        //    {
        //        return 0; //1 tot hon
        //    }
        //    else
        //    {
        //        return 1;
        //    }
        //}

        public int compare_new(Tour T1, Tour T2)
        {
            Tour pos_T1 = new Tour();
            Tour pos_T2 = new Tour();
            pos_T1 = deep_copy(T1);
            pos_T2 = deep_copy(T2);

            if ((double) pos_T1.fac_cost[0] >= (double) pos_T2.fac_cost[0])
            {
                return 0; //1 tot hon
            }
            else
            {
                return 1;
            }
        }

        public int compare(Tour T1, Tour T2)
        {
            Tour pos_T1 = new Tour();
            Tour pos_T2 = new Tour();
            pos_T1 = deep_copy(T1);
            pos_T2 = deep_copy(T2);

            if ((double) pos_T1.fac_cost[0] > (double) pos_T2.fac_cost[0])
            {
                pos_T1.sub_rank.Add(2);
                pos_T2.sub_rank.Add(1);//cang thap cang tot
            }
            else
            {
                if((double)pos_T1.fac_cost[0] < (double)pos_T2.fac_cost[0])
                {
                    pos_T1.sub_rank.Add(1);
                    pos_T2.sub_rank.Add(2);//cang thap cang tot
                }
                else
                {
                    pos_T1.sub_rank.Add(1);
                    pos_T2.sub_rank.Add(1);//cang thap cang tot
                }
            }
            if ((double)pos_T1.fac_cost[1] > (double)pos_T2.fac_cost[1])
            {
                pos_T1.sub_rank.Add(2);
                pos_T2.sub_rank.Add(1);//cang thap cang tot
            }
            else
            {
                if ((double)pos_T1.fac_cost[1] < (double)pos_T2.fac_cost[1])
                {
                    pos_T1.sub_rank.Add(1);
                    pos_T2.sub_rank.Add(2);//cang thap cang tot
                }
                else
                {
                    pos_T1.sub_rank.Add(1);
                    pos_T2.sub_rank.Add(1);//cang thap cang tot
                }
            }

            pos_T1.sub_rank.Sort();
            pos_T1.skill_factor = (int)pos_T1.sub_rank[0];
            pos_T2.sub_rank.Sort();
            pos_T2.skill_factor = (int)pos_T2.sub_rank[0];


            pos_T1.scalar_fitness = (double)1 / (double)pos_T1.skill_factor;
            pos_T2.scalar_fitness = (double)1 / (double)pos_T2.skill_factor;

            if (pos_T1.scalar_fitness > pos_T2.scalar_fitness)
            {
                return 0; //1 tot hon
            }
            else
            {
                if(pos_T1.scalar_fitness < pos_T2.scalar_fitness)
                    return 1;
                else
                    return 2;
            }
        }

        public Tour swap_adjacent(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);
            int i, j;

            //local_latency = 0;
            bool improve = true;
            if (tour_current.Ltour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;
                    while (i < tour_current.Ltour.Count - 1)
                    {
                        int t;
                        j = i + 1;

                        //double orgin_length = (double)tour_current.fac_cost[0];
                        //double orgin_latency = (double)tour_current.fac_cost[1];
                        //tour_current = (Tour)clear_tour(tour_current);

                        //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                        //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                        //Console.WriteLine("local_length");
                        //Console.WriteLine(local_length);
                        //Console.WriteLine("local_latency");
                        //Console.WriteLine(local_latency);


                        t = (int)tour_current.Ltour[i];
                        tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                        tour_current.Ltour[j] = (int)t;

                        tour_current = (Tour)clear_tour(tour_current);
                        double length = tour_current.Calculate_fac_TSP(Lvertex);
                        double latency = tour_current.Calculate_fac_TRP(Lvertex);
                        //Console.ReadKey();

                        //if ((Math.Round(length) != Math.Round(local_length)) || (Math.Round(latency) != Math.Round(local_latency)))
                        //{
                        //    Console.WriteLine("error");
                        //    Console.ReadKey();
                        //}
                        if (compare(initial_tour, tour_current) == 1)
                        {
                            //tour_current = deep_copy(initial_tour);

                            //Console.WriteLine(initial_tour.fac_cost[0]);
                            //Console.WriteLine(tour_current.fac_cost[0]);
                            //t = (int)tour_current.Ltour[i];
                            //tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)t;

                            //tour_current = (Tour)clear_tour(tour_current);
                            //tour_current.Calculate_fac_TSP(Lvertex);
                            //tour_current.Calculate_fac_TRP(Lvertex);
                            //Console.ReadKey();
                            //
                            initial_tour = deep_copy(tour_current);
                            improve = true;
                            best_found = true;

                            //Console.WriteLine(initial_tour.fac_cost[0]);
                            //Console.WriteLine(initial_tour.fac_cost[1]);
                            //Console.ReadKey();
                        }
                        else
                        {
                            tour_current = deep_copy(initial_tour);
                        }
                        if (improve == true) break;
                        else
                            i++;
                        //Console.WriteLine(i);
                    }

                }
            }
            return initial_tour;
        }

        public Tour remove_insert(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            int i;
            bool improve = true;
            if (initial_tour.Ltour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;
                    while (i < tour_current.Ltour.Count - 1)
                    {
                        //Console.WriteLine("FASLEELFLFLFLFLFLFLLFFL");
                        //Console.ReadKey();
                        int num = (int)tour_current.Ltour[i];
                        tour_current.Ltour.Remove(num);
                        tour_current.Ltour.Add(num);

                        tour_current = (Tour)clear_tour(tour_current);
                        tour_current.Calculate_fac_TSP(Lvertex);
                        tour_current.Calculate_fac_TRP(Lvertex);
                        //tour_current.check_sol(tour_current.Ltour);
                        //Console.WriteLine(tour_current.fea);
                        if (tour_current.fea == false)
                        {
                            Console.WriteLine("trueueueueufufufufufuuffufufu");
                            Console.ReadKey();
                        }
                        if (compare(initial_tour, tour_current) == 1)
                        {
                            initial_tour = deep_copy(tour_current);
                            improve = true;
                            best_found = true;
                        }
                        else
                        {
                            tour_current = deep_copy(initial_tour);
                        }
                        if (improve == true) break;
                        else
                            i++;
                    }
                }
            }
            return (initial_tour);
        }

        public Tour move_two(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);
            int i, j;

            if (initial_tour.Ltour.Count >= 3)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 2)
                {
                    j = i + 2;

                    int t;

                    //double orgin_length = (double)tour_current.fac_cost[0];
                    //double orgin_latency = (double)tour_current.fac_cost[1];
                    //tour_current = (Tour)clear_tour(tour_current);

                    //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                    //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                    //Console.WriteLine("local_latency");
                    //Console.WriteLine(local_latency);
                    //Console.WriteLine("local_length");
                    //Console.WriteLine(local_length);


                    t = (int)tour_current.Ltour[i];
                    tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                    tour_current.Ltour[j] = (int)t;

                    tour_current = (Tour)clear_tour(tour_current);
                    tour_current.Calculate_fac_TSP(Lvertex);
                    tour_current.Calculate_fac_TRP(Lvertex);

                    //Console.WriteLine("local_latency");
                    //Console.ReadKey();

                    if (compare(initial_tour, tour_current) == 1)
                    {

                        //t = (int)tour_current.Ltour[i];
                        //tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                        //tour_current.Ltour[j] = (int)t;

                        initial_tour = deep_copy(tour_current);
                        best_found = true;
                    }
                    else
                    {
                        tour_current = deep_copy(initial_tour);
                    }

                    i++;
                }

            }
            return (tour_current);
        }

        public Tour move_one(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);
            int i, j;

            if (initial_tour.Ltour.Count >= 3)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 1)
                {
                    j = i + 1;

                    int t;

                    //double orgin_length = (double)tour_current.fac_cost[0];
                    //double orgin_latency = (double)tour_current.fac_cost[1];
                    //tour_current = (Tour)clear_tour(tour_current);

                    //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                    //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                    t = (int)tour_current.Ltour[i];
                    tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                    tour_current.Ltour[j] = (int)t;

                    tour_current = (Tour)clear_tour(tour_current);
                    tour_current.Calculate_fac_TSP(Lvertex);
                    tour_current.Calculate_fac_TRP(Lvertex);

                    //Console.WriteLine("local_latency");
                    //Console.WriteLine(local_latency);
                    //Console.WriteLine("local_length");
                    //Console.WriteLine(local_length);


                    //t = (int)tour_current.Ltour[i];
                    //tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                    //tour_current.Ltour[j] = (int)t;

                    //tour_current = (Tour)clear_tour(tour_current);
                    //tour_current.Calculate_fac_TSP(Lvertex);
                    //tour_current.Calculate_fac_TRP(Lvertex);

                    //Console.WriteLine("local_latency");
                    //Console.ReadKey();

                    if (compare(initial_tour, tour_current) == 1)
                    {

                        //t = (int)tour_current.Ltour[i];
                        //tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                        //tour_current.Ltour[j] = (int)t;

                        initial_tour = deep_copy(tour_current);
                        best_found = true;
                    }
                    else
                    {
                        tour_current = deep_copy(initial_tour);
                    }
                    i++;
                }

            }
            return (tour_current);
        }

        public Tour swap(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 2)
                {
                    j = i + 1;
                    while (j < tour_current.Ltour.Count - 1)
                    {
                        int t;

                        //double orgin_length = (double)tour_current.fac_cost[0];
                        //double orgin_latency = (double)tour_current.fac_cost[1];
                        //tour_current = (Tour)clear_tour(tour_current);

                        //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                        //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                      
                        //Console.WriteLine("local_latency");
                        //Console.WriteLine(local_length_1);
                        //Console.WriteLine("local_length");
                        //Console.WriteLine(local_latency_1);

                        //tour_current = deep_copy(initial_tour);

                        t = (int)tour_current.Ltour[j];
                        tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                        tour_current.Ltour[i] = (int)t;

                        //t = (int)tour_current.Ltour[j];
                        //tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                        //tour_current.Ltour[k] = (int)t;

                        tour_current = (Tour)clear_tour(tour_current);
                        tour_current.Calculate_fac_TSP(Lvertex);
                        tour_current.Calculate_fac_TRP(Lvertex);
                        //Console.ReadKey();

                        if (compare(initial_tour, tour_current) == 1)
                        {
                            //t = (int)tour_current.Ltour[i];
                            //tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)t;

                            initial_tour = deep_copy(tour_current);
                            best_found = true;
                        }
                        else
                        {
                            tour_current = deep_copy(initial_tour);
                        }
                        j++;
                    }
                    i++;
                }
            }

            return initial_tour;
        }

        public Tour improve_greedy_two_opt(Tour initial_tour, ArrayList Lvertex)
        {
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);
            int i, j;

            //local_latency = 0;
            bool improve = true;
            if (initial_tour.Ltour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;

                    while (i < tour_current.Ltour.Count - 2)
                    {
                        j = i + 2;
                        while (j < tour_current.Ltour.Count)
                        {
                            int t;
                            //local_latency = (double)latency_tour_swap_edge(tour_current, Lvertex, i, j, fitness_before);
                            t = (int)tour_current.Ltour[i];
                       
                            tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                            tour_current.Ltour[j] = (int)t;
                            tour_current.Ltour.Reverse(i, j - i + 1);

                            tour_current = (Tour)clear_tour(tour_current);
                            tour_current.Calculate_fac_TSP(Lvertex);
                            tour_current.Calculate_fac_TRP(Lvertex);

                            if (compare(initial_tour, tour_current) == 1)
                            {
                                initial_tour = deep_copy(tour_current);
                                improve = true;
                                best_found = true;
                            }
                            else
                            {
                                tour_current = deep_copy(initial_tour);
                            }
                            if (improve == true) break;
                            else j++;
                        }
                        if (improve == true) break;
                        else i++;
                    }
                }
            }
            return initial_tour;
        }

        public Tour greedy_three_edge_opt_Case_1(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 2)
                {
                    j = i + 1;
                    while (j < tour_current.Ltour.Count - 1)
                    {
                        int t;
                        k = j + 1;
                        while (k < tour_current.Ltour.Count)
                        {
                            double orgin_length = (double)tour_current.fac_cost[0];
                            double orgin_latency = (double)tour_current.fac_cost[1];
                            tour_current = (Tour)clear_tour(tour_current);

                            double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                            double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                            t = (int)tour_current.Ltour[j];
                            tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                            tour_current.Ltour[i] = (int)t;

                            double orgin_length_1 = (double)tour_current.fac_cost[0];
                            double orgin_latency_1 = (double)tour_current.fac_cost[1];
                            tour_current = (Tour)clear_tour(tour_current);

                            double local_length_1 = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_length_1);
                            double local_latency_1 = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_latency_1);

                            //Console.WriteLine("local_latency");
                            //Console.WriteLine(local_length_1);
                            //Console.WriteLine("local_length");
                            //Console.WriteLine(local_latency_1);

                            //tour_current = deep_copy(initial_tour);

                            //t = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                            //tour_current.Ltour[i] = (int)t;

                            //t = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                            //tour_current.Ltour[k] = (int)t;

                            //tour_current = (Tour)clear_tour(tour_current);
                            //tour_current.Calculate_fac_TSP(Lvertex);
                            //tour_current.Calculate_fac_TRP(Lvertex);
                            //Console.ReadKey();

                            if (compare(initial_tour, tour_current) == 1)
                            {
                                t = (int)tour_current.Ltour[j];
                                tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                                tour_current.Ltour[k] = (int)t;

                                initial_tour = deep_copy(tour_current);
                                best_found = true;
                            }
                            else
                            {
                                tour_current = deep_copy(initial_tour);
                            }
                            k++;
                        }
                        j++;
                    }
                    i++;
                }
            }
            return initial_tour;
        }

        public Tour greedy_three_edge_opt_Case_2(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 2)
                {
                    j = i + 1;
                    while (j < tour_current.Ltour.Count - 1)
                    {
                        k = j + 1;
                        while (k < tour_current.Ltour.Count)
                        {
                            int t = (int)tour_current.Ltour[j];
                            tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                            tour_current.Ltour[k] = (int)t;


                            t = (int)tour_current.Ltour[i];
                            tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                            tour_current.Ltour[j] = (int)t;

                            tour_current = (Tour)clear_tour(tour_current);
                            tour_current.Calculate_fac_TSP(Lvertex);
                            tour_current.Calculate_fac_TRP(Lvertex);

                            if (compare(initial_tour, tour_current) == 1)
                            {
                                initial_tour = deep_copy(tour_current);
                                best_found = true;
                            }
                            else
                            {
                                tour_current = deep_copy(initial_tour);
                            }
                            k++;
                        }
                        j++;
                    }
                    i++;
                }
            }
            return initial_tour;
        }

        public Tour first_or(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 2)
                {
                    j = i + 1;
                    while (j < tour_current.Ltour.Count - 1)
                    {
                        int t;
                        k = j + 1;

                        //double orgin_length = (double)tour_current.fac_cost[0];
                        //double orgin_latency = (double)tour_current.fac_cost[1];
                        //tour_current = (Tour)clear_tour(tour_current);

                        //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length);
                        //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency);

                        //t = (int)tour_current.Ltour[j];
                        //tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                        //tour_current.Ltour[i] = (int)t;

                        //double orgin_length_1 = (double)tour_current.fac_cost[0];
                        //double orgin_latency_1 = (double)tour_current.fac_cost[1];
                        //tour_current = (Tour)clear_tour(tour_current);

                        //double local_length_1 = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_length_1);
                        //double local_latency_1 = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_latency_1);

                        //Console.WriteLine("local_latency");
                        //Console.WriteLine(local_length_1);
                        //Console.WriteLine("local_length");
                        //Console.WriteLine(local_latency_1);

                        //tour_current = deep_copy(initial_tour);

                        t = (int)tour_current.Ltour[j];
                        tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                        tour_current.Ltour[i] = (int)t;

                        t = (int)tour_current.Ltour[j];
                        tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                        tour_current.Ltour[k] = (int)t;

                        tour_current = (Tour)clear_tour(tour_current);
                        tour_current.Calculate_fac_TSP(Lvertex);
                        tour_current.Calculate_fac_TRP(Lvertex);
                        //Console.ReadKey();

                        if (compare(initial_tour, tour_current) == 1)
                        {
                            //t = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                            //tour_current.Ltour[k] = (int)t;

                            initial_tour = deep_copy(tour_current);
                            best_found = true;
                        }
                        else
                        {
                            tour_current = deep_copy(initial_tour);
                        }
                        j++;
                    }
                    i++;
                }
            }

            return initial_tour;
        }

        public Tour second_or(Tour initial_tour, ArrayList Lvertex)
        {
            int i, j, k;
            Tour tour_current = new Tour();
            tour_current = deep_copy(initial_tour);

            if (tour_current.Ltour.Count >= 4)
            {
                i = 1;
                while (i < tour_current.Ltour.Count - 3)
                {
                    j = i + 1;
                    while (j < tour_current.Ltour.Count - 2)
                    {
                        int t;
                        k = j + 1;

                        //double orgin_length = (double)tour_current.fac_cost[0];
                        //double orgin_latency = (double)tour_current.fac_cost[1];
                        //tour_current = (Tour)clear_tour(tour_current);

                        //double local_length = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_length);
                        //double local_latency = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, j, k, (double)orgin_latency);

                        //t = (int)tour_current.Ltour[j];
                        ///tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                        //tour_current.Ltour[k] = (int)t;

                        ///double orgin_length_1 = (double)tour_current.fac_cost[0];
                        //double orgin_latency_1 = (double)tour_current.fac_cost[1];
                        //tour_current = (Tour)clear_tour(tour_current);

                        //double local_length_1 = tour_current.length_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_length_1);
                        //double local_latency_1 = tour_current.latency_tour_opt_node(tour_current.Ltour, Lvertex, i, j, (double)orgin_latency_1);

                        //Console.WriteLine("local_latency");
                        //Console.WriteLine(local_length_1);
                        //Console.WriteLine("local_length");
                        //Console.WriteLine(local_latency_1);

                        //tour_current = deep_copy(initial_tour);

                        t = (int)tour_current.Ltour[j];
                        tour_current.Ltour[j] = (int)tour_current.Ltour[k];
                        tour_current.Ltour[k] = (int)t;

                        t = (int)tour_current.Ltour[j];
                        tour_current.Ltour[j] = (int)tour_current.Ltour[i];
                        tour_current.Ltour[i] = (int)t;

                        tour_current = (Tour)clear_tour(tour_current);
                        tour_current.Calculate_fac_TSP(Lvertex);
                        tour_current.Calculate_fac_TRP(Lvertex);
                        //Console.ReadKey();

                        if (compare(initial_tour, tour_current) == 1)
                        {
                            //t = (int)tour_current.Ltour[i];
                            //tour_current.Ltour[i] = (int)tour_current.Ltour[j];
                            //tour_current.Ltour[j] = (int)t;

                            initial_tour = deep_copy(tour_current);
                            best_found = true;
                        }
                        else
                        {
                            tour_current = deep_copy(initial_tour);
                        }
                        j++;
                    }
                    i++;
                }
            }
            
            return initial_tour;
        }

    }
}
