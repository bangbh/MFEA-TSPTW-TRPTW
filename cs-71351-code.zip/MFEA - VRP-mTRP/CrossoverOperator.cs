﻿using System;
using System.Collections;

namespace MFEA
{
    class CrossoverOperator
    {
        public ArrayList boy_tour = new ArrayList();
        public ArrayList girl_tour = new ArrayList();

        public void MPX(ArrayList father, ArrayList mother)
        {
            Random rand = new Random();
            int random_cut_1, random_cut_2;

            ArrayList tem_father = new ArrayList();
            ArrayList tem_mother = new ArrayList();
            tem_father = (ArrayList)father.Clone();
            tem_mother = (ArrayList)mother.Clone();
            tem_father.RemoveAt(0); tem_mother.RemoveAt(0);

            random_cut_1 = rand.Next(tem_father.Count - 1);
            do
            {
                random_cut_2 = rand.Next(tem_mother.Count - 1);
            }

            while (random_cut_1 >= random_cut_2);

            MPX_Array(tem_father, tem_mother, random_cut_1, random_cut_2, 1);
            MPX_Array(tem_mother, tem_father, random_cut_1, random_cut_2, 2);
        }

        public void MPX_Array(ArrayList father, ArrayList mother, int random_cut_1, int random_cut_2, int number)
        {
            int i, j;

            ArrayList Tour_child = new ArrayList();

            Tour_child = (ArrayList)father.Clone();
            i = random_cut_1;

            while (i <= random_cut_2)
            {
                Tour_child.Remove((int)father[i]);
                i++;
            }

            for (i = 0; i < mother.Count; i++)
            {
                if (Tour_child.Contains(mother[i]) == false)
                {
                    Tour_child.Add(mother[i]);
                }
            }

            if (number == 1)
            {
                boy_tour = (ArrayList)Tour_child.Clone();
                boy_tour.Insert(0, 0);
                //Console.WriteLine("boy_tour.COUNT");
                //Console.WriteLine(boy_tour.Count);

                if (check_sol(boy_tour) == false)
                {
                    string line = "";
                    for (int ii = 0; ii < boy_tour.Count; ii++)
                    {

                        line = line + " " + boy_tour[ii].ToString();
                    }
                    Console.WriteLine("FALSLSLL");

                    Console.WriteLine(line);
                    Console.WriteLine("FALSLSLL");
                    Console.ReadKey();
                }
            }
            else
            {
                girl_tour = (ArrayList)Tour_child.Clone();
                girl_tour.Insert(0, 0);
                //Console.WriteLine("girl_tour.COUNT");
                //Console.WriteLine(girl_tour.Count);

                if (check_sol(girl_tour) == false)
                {
                    string line = "";
                    for (int ii = 0; ii < girl_tour.Count; ii++)
                    {

                        line = line + " " + girl_tour[ii].ToString();
                    }
                    Console.WriteLine("FALSLSLL");

                    Console.WriteLine(line);
                    Console.WriteLine("FALSLSLL");
                    Console.ReadKey();
                }
            }

        }
        public void OX(ArrayList father, ArrayList mother)
        {
            Random rand = new Random();
            int Random_number, random;
            ArrayList pos_number = new ArrayList();

            ArrayList tem_father = new ArrayList();
            ArrayList tem_mother = new ArrayList();
            tem_father = (ArrayList)father.Clone();
            tem_mother = (ArrayList)mother.Clone();
            tem_father.RemoveAt(0); tem_mother.RemoveAt(0);

            do
            {
                Random_number = rand.Next(tem_father.Count);
            }
            while ((Random_number == 0) || (Random_number == tem_father.Count - 1));


            pos_number.Add(0);
            while (pos_number.Count <= Random_number)
            {
                do
                {
                    random = rand.Next(tem_father.Count - 1);
                }
                while ((random == 0) || (pos_number.Contains(random) == true));
                pos_number.Add(random);
            }


            pos_number.Sort();

            CYCLE_OX(tem_father, tem_mother, 1, pos_number);
            CYCLE_OX(tem_mother, tem_father, 2, pos_number);
        }
        public void CYCLE_OX(ArrayList father, ArrayList mother, int number, ArrayList pos_number)
        {


            ArrayList Second_post_value = new ArrayList();
            ArrayList Second_post_number = new ArrayList();
            ArrayList Tour_child = new ArrayList();

            int i;


            for (i = 0; i < pos_number.Count; i++)
            {
                Second_post_value.Add((int)mother[(int)pos_number[i]]);
            }

            for (i = 0; i < Second_post_value.Count; i++)
            {
                int pos = father.IndexOf((int)Second_post_value[i]);
                if (pos >= 0)
                {
                    Second_post_number.Add(pos);
                }
            }

            Tour_child = (ArrayList)father.Clone();
            Second_post_number.Sort();

            for (i = 0; i < Second_post_number.Count; i++)
            {
                Tour_child[(int)Second_post_number[i]] = Second_post_value[i];
            }

            if (number == 1)
            {
                boy_tour = (ArrayList)Tour_child.Clone();
                boy_tour.Insert(0, 0);
            }
            else
            {
                girl_tour = (ArrayList)Tour_child.Clone();
                girl_tour.Insert(0, 0);
            }
        }
        public void POS(ArrayList father, ArrayList mother)
        {
            Random rand = new Random();
            int random_cut_1, random_cut_2;

            ArrayList tem_father = new ArrayList();
            ArrayList tem_mother = new ArrayList();

            tem_father = (ArrayList)father.Clone();
            tem_mother = (ArrayList)mother.Clone();

            tem_father.RemoveAt(0);
            tem_mother.RemoveAt(0);

            random_cut_1 = rand.Next(tem_father.Count - 2);
            do
            {
                random_cut_2 = rand.Next(tem_mother.Count - 1);
            }
            while ((random_cut_1 >= random_cut_2) || (random_cut_2 == 0));



            CYCLE_POS(tem_father, tem_mother, 1, random_cut_1, random_cut_2);
            CYCLE_POS(tem_mother, tem_father, 2, random_cut_1, random_cut_2);

        }

        public void CYCLE_POS(ArrayList father, ArrayList mother, int number, int random_cut_1, int random_cut_2)
        {

            ArrayList Map_OX1 = new ArrayList();
            ArrayList Tour_child = new ArrayList();

            int i;
            Stack myStack = new Stack();

            Map_OX1.Clear();

            Tour_child = (ArrayList)father.Clone();

            for (i = 0; i < Tour_child.Count; i++)
            {
                if ((i < random_cut_1) || (i > random_cut_2))
                {
                    Tour_child[i] = 0;
                }
            }

            int j = random_cut_2;
            for (i = 0; i < random_cut_1; i++)
            {
                while (j >= 0)
                {

                    if (Tour_child.Contains(mother[j]) == false)
                    {
                        if (Map_OX1.Contains(j) == false)
                        {
                            Map_OX1.Add(j); break;
                        }
                    }
                    if (j == 0) break;
                    j--;
                }

            }

            Map_OX1.Add(-1);

            for (i = Tour_child.Count - 1; i > random_cut_2; i--)
            {
                while (j >= 0)
                {

                    if (Tour_child.Contains(mother[j]) == false)
                    {
                        if (Map_OX1.Contains(j) == false)
                        {
                            Map_OX1.Add(j); break;
                        }
                    }
                    if (j == 0) break;
                    j--;
                }
                if (j == 0) j = mother.Count - 1;
                while (j > random_cut_2)
                {
                    if (Tour_child.Contains(mother[j]) == false)
                    {
                        if (Map_OX1.Contains(j) == false)
                        {
                            Map_OX1.Add(j); break;
                        }
                    }
                    j--;
                    if (j == random_cut_2) break;
                }
            }
            i = Map_OX1.IndexOf(-1);
            i--;
            j = 0;
            while (i >= 0)
            {
                Tour_child[j] = mother[(int)Map_OX1[i]];
                i--;
                j++;
            }

            i = Map_OX1.Count - 1;
            j = random_cut_2 + 1;

            while ((int)Map_OX1[i] != -1)
            {
                Tour_child[j] = mother[(int)Map_OX1[i]];
                i--;
                j++;
            }

            if (number == 1)
            {
                boy_tour = (ArrayList)Tour_child.Clone();
                boy_tour.Insert(0, 0);
                //if (check_sol(boy_tour)==false)
                //{

                //string line = "";
                //for (int ii = 0; ii < boy_tour.Count; ii++)
                //{

                //    line = line + " " + boy_tour[ii].ToString();
                //}
                //Console.WriteLine("FALSLSLL");

                //Console.WriteLine(line);
                //Console.WriteLine("FALSLSLL");
                //Console.ReadKey();
                //}
            }
            else
            {
                girl_tour = (ArrayList)Tour_child.Clone();
                girl_tour.Insert(0, 0);
                //Console.WriteLine("FALSLSLL");
                //Console.WriteLine(check_sol(girl_tour));
                //if (check_sol(girl_tour)==false)
                //{
                //string line = "";
                //for (int ii = 0; ii < girl_tour.Count; ii++)
                //{

                //    line = line + " " + girl_tour[ii].ToString();
                //}
                //Console.WriteLine("FALSLSLL");

                //Console.WriteLine(line);
                //Console.WriteLine("FALSLSLL");
                //Console.ReadKey();
                //}
            }
        }
        public bool check_sol(ArrayList Ltour)
        {
            bool fea = true;
            //int num = 0;
            for (int i = 0; i < Ltour.Count - 1; i++)
            {
                for (int j = i + 1; j < Ltour.Count; j++)
                {
                    if ((int)Ltour[i] == (int)Ltour[j])
                    {
                        //Console.WriteLine(Ltour[i]);
                        //num = (int)Ltour[i];
                        //Console.ReadKey();

                        fea = false;
                        break;
                    }
                }
            }
            if (fea == false)
            {
                Console.WriteLine("false");
                Console.ReadKey();
            }
            return fea;
        }
    }
}
