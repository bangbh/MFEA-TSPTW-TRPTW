﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Globalization;
using System.Threading;
using System.Diagnostics;

namespace MFEA
{
    class Population : List<Tour>
    {
        static public double best_TSP = double.MaxValue;
        static public double best_TRP = double.MaxValue;
        static public ArrayList best_TSP_Sol = new ArrayList();
        static public ArrayList best_TRP_Sol = new ArrayList();

        public void print()
        {

            string name = "population-" + ".txt";
            StreamWriter sr = new StreamWriter(name, false);

            try
            {
                for (int i = 0; i < this.Count; i++)
                {

                    string line = "";

                    Console.WriteLine("k_vehicle");
                    Console.WriteLine(this[i].Ltour.Count);

                    for (int j = 0; j < this[i].Ltour.Count; j++)
                    {
                        line = line + " " + this[i].Ltour[j].ToString();
                    }
                    sr.WriteLine(line + "----" + this[i].fac_cost[0] + "---" + this[i].fac_cost[1] + "---" 
                        + this[i].skill_factor + "----" + this[i].scalar_fitness + "----" + 
                        "----" + this[i].sub_rank[0] + "----" + this[i].sub_rank[1] + "----" + this[i].rank );
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            sr.Close();
        }

        public Population Init_population(int k_vehicle, int popluation_size, int start_vertex, int nearest_vertex_number, Rdata rdata, Random rand)
        {
            for (int i = 0; i < popluation_size; i++)
            {
                Tour tour = new Tour();
                int population_selection = rand.Next(2);/// population_selection = 1;
                if (population_selection == 0)
                {
                    tour.Initial_tour_find_rand(k_vehicle, start_vertex, nearest_vertex_number, rdata.Lvertex, rdata.D, rdata.Q);
                }
                else
                {
                    tour.Initial_tour_find_heuristic(k_vehicle, start_vertex, nearest_vertex_number, rdata.Lvertex, rdata.D, rdata.Q, rand);
                }
                this.Add(tour);
                //Console.WriteLine(this.Count);
                //Console.WriteLine(this[0].fac_cost[1]);
                //Console.ReadKey();
            }

            return this;
        }

        public ArrayList selection_operator(int group_size, Random rand)
        {
            ArrayList tour_group = new ArrayList();
            int tour_count, top_tour, temp_tour;

            for (tour_count = 0; tour_count < group_size; tour_count++)
            {
                tour_group.Add(rand.Next(this.Count));
            }

            //bubble sort on the neighborhood city group
            for (tour_count = 0; tour_count < group_size - 1; tour_count++)
            {
                top_tour = tour_count;
                for (int i = top_tour + 1; i < group_size; i++)
                {
                    //chỉ số rank càng lớn thì càng top
                    if (((Tour)this[(int) tour_group[i]]).rank > ((Tour)this[(int)tour_group[top_tour]]).rank)
                    {
                        top_tour = i;
                    }
                }
                if (top_tour != tour_count)
                {
                    temp_tour = (int) tour_group[(int)tour_count];
                    tour_group[tour_count] = tour_group[top_tour];
                    tour_group[top_tour] = temp_tour;
                }
            }
            return tour_group;
        }

        public Population Clear_population(int population_size)
        {
            for (int i = 0; i < this.Count; i++)
            {
                ((Tour)this[i]).scalar_fitness = -1;
                ((Tour)this[i]).skill_factor  = -1;
                ((Tour)this[i]).sub_rank.Clear();
                ((Tour)this[i]).rank = -1;
                //((Tour)this[i]).fac_cost.Clear(); 
            }

            return this;
        }

        public Population Elite_population(int population_size, Random rand, ArrayList Lvertex)
        {
            //this.Custom_population(population_size, rand, Lvertex);
            this.Clear_population(population_size);
            this.Rank_population();
            this.RemoveRange(population_size, this.Count - population_size);
            this.Rank_population();

            return this;
        }

        public Population Custom_population(int population_size, Random rand, ArrayList Lvertex)
        {
            for (int i = 0; i < this.Count; i++)
            {
                MutationOperator MO = new MutationOperator();
                MO.Random_mutation(this[i].Ltour, rand);
                this[i].Ltour = (ArrayList)MO.child.Clone();

                this[i].fac_cost.Clear();
                this[i].Calculate_fac_TSP(Lvertex);
                this[i].Calculate_fac_TRP(Lvertex);
            }

            return this;
        }

        public void Rank_population()
        {
            this.Rank_TSP_population();
            this.Rank_TRP_population();
            this.Rank_skill_population();
            this.Rank_scalar_population();
            this.Sort_population();
        }

        public Tour deep_copy(Tour T)
        {
            Tour pos_T = new Tour();

            pos_T.fac_cost = (ArrayList)T.fac_cost.Clone();
            pos_T.sub_rank = (ArrayList)T.sub_rank.Clone();
            pos_T.skill_factor = (double)T.skill_factor;
            pos_T.scalar_fitness = (double)T.scalar_fitness;
            pos_T.rank = (int)T.rank;
            pos_T.Ltour = (ArrayList)T.Ltour.Clone();

            return pos_T;
        }

        public Population Sort_population()
        {

            for (int i = 0; i < this.Count - 1; i++)
            {
                for (int j = i + 1; j < this.Count; j++)
                {
                    if(((Tour)this[i]).rank < ((Tour)this[j]).rank)
                    {
                        Tour tour = new Tour();
                        tour = deep_copy((Tour)this[j]);
                        this[j] = deep_copy((Tour)this[i]);
                        this[i] = deep_copy((Tour)tour);
                    }
                }
            }

            return this;
        }
        public void Rank_scalar_population()
        {
            ArrayList rank = new ArrayList();
            for (int i = 0; i < this.Count; i++)
            {
                ((Tour)this[i]).scalar_fitness = (double)1 / (double)((Tour)this[i]).skill_factor;
            }

            for (int i = 0; i < this.Count; i++)
            {
                rank.Add(((Tour)this[i]).scalar_fitness);
            }
            rank.Sort();

            for (int i = 0; i < this.Count; i++)
            {
                if (rank.IndexOf((double)(((Tour)this[i]).scalar_fitness)) >= 0)
                {
                    this[i].rank = rank.IndexOf((double)(((Tour)this[i]).scalar_fitness));
                }
            }
        }

        public void Rank_skill_population()
        {
            for (int i = 0; i < this.Count; i++)
            {
                ((Tour)this[i]).sub_rank.Sort();
                ((Tour)this[i]).skill_factor = (int) ((Tour)this[i]).sub_rank[0];
            }
        }

        public void Rank_TSP_population()
        {
            ArrayList rank = new ArrayList();
            for (int i = 0; i < this.Count; i++)
            {
                rank.Add(((Tour)this[i]).fac_cost[0]);
            }
            rank.Sort();//cang nho cang tot
            //rank.Reverse();

            for (int i = 0; i < this.Count; i++)
            {
                this[i].sub_rank.Add(rank.IndexOf((double)((Tour)this[i]).fac_cost[0]) + 1);
            }
        }

        public void Rank_TRP_population()
        {
            ArrayList rank = new ArrayList();
            for (int i = 0; i < this.Count; i++)
            {
                rank.Add(((Tour)this[i]).fac_cost[1]);
            }
            rank.Sort();//cang nho cang tot
            //rank.Reverse();


            for (int i = 0; i < this.Count; i++)
            {
                this[i].sub_rank.Add(rank.IndexOf((double)((Tour)this[i]).fac_cost[1]) + 1);
            }
        }

        public void Add_population(Tour new_tour, ArrayList Lvertex)
        {
            new_tour.Calculate_fac_TSP(Lvertex);
            new_tour.Calculate_fac_TRP(Lvertex);
            this.Add(new_tour);

            this.Rank_TSP_population();
            this.Rank_TRP_population();
            this.Rank_skill_population();
            this.Rank_scalar_population();
        }
    }
}
