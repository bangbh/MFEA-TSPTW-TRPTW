﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Globalization;
using System.Threading;
using System.Diagnostics;

namespace MFEA
{
    class Tour : List<Vertex>
    {
        public ArrayList fac_cost = new ArrayList();
        public ArrayList sub_rank = new ArrayList();
        static public double TSPTW_total_min = double.MaxValue;
        static public double TRPTW_total_min = double.MaxValue;
        public bool fea_TSPTW = true;
        public bool fea_TRPTW = true;
        public double local_cost = 0;
        public double skill_factor = 0;
        public double scalar_fitness = 0;
        public int rank = 0;
        public ArrayList Ltour = new ArrayList();
        public bool fea = true;
        public double length_tour_swap_edge(ArrayList orgin_tour, ArrayList Lvertex, int i, int j, double orgin_fitness)
        {
            double fac_TSP = 0;
            double n, Ti1, Ti2 = 0;
            n = orgin_tour.Count;

            if (j < orgin_tour.Count - 1)
            {
                Ti1 = 1 * ((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]] - (double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]);
                Ti2 = 1 * ((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[i + 2]] - (double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[i + 2]]);
                fac_TSP = Ti1 + Ti2;
            }
            else
            {
                Ti1 = 1 * ((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]] - (double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]);
                fac_TSP = Ti1;
            }
            fac_TSP = orgin_fitness + fac_TSP;
            this.fac_cost.Add(fac_TSP);

            if (fac_TSP < Population.best_TSP)
            {
                write_file(Program.sw.ElapsedMilliseconds / 1000, Program.name_file, 2, fac_TSP);
                Population.best_TRP = fac_TSP;
                Console.WriteLine("Population.best_TRP");
                Console.WriteLine(Population.best_TSP);
            }
            return fac_TSP;
        }

        public double length_tour_opt_node(ArrayList orgin_tour, ArrayList Lvertex, int i1, int j1, double orgin_fitness)
        {
            double fac_TSP = 0;
            double n, Ti1, Ti2, Tj1, Tj2 = 0;
            n = orgin_tour.Count;
            int i, j;
            if (i1 < j1)
            {
                i = i1;
                j = j1;
            }
            else
            {
                i = j1;
                j = i1;
            }

            if (j < orgin_tour.Count - 1)
            {
                //Console.WriteLine("ENTER1");

                if (i != (j - 1))
                {
                    //Console.WriteLine("ENTER2");

                    Ti1 = 1 * Math.Round(((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]));
                    Ti2 = 1 * Math.Round(((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[i + 1]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[i + 1]]));
                    Tj1 = 1 * Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[i]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[j]]);
                    Tj2 = 1 * Math.Round(((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[j + 1]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[j + 1]]));
                    fac_TSP = Ti1 + Ti2 + Tj1 + Tj2;
                }
                else
                {
                    //Console.WriteLine("ENTER3");

                    Ti1 = 1 * Math.Round(((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]));
                    Tj2 = 1 * Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[j + 1]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[j + 1]]);
                    fac_TSP = Ti1 + Tj2;
                }
            }
            else
            {
                if (i != (j - 1))
                {
                    //Console.WriteLine("ENTER4");

                    Ti1 = 1 * Math.Round(((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]));
                    Ti2 = 1 * Math.Round(((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[i + 1]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[i + 1]]));
                    Tj1 = 1 * Math.Round(((double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[i]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[j]]));
                    Tj2 = 1 * Math.Round(((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[0]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[0]]));

                    fac_TSP = Ti1 + Ti2 + Tj1 + Tj2;
                }
                else
                {
                    //Console.WriteLine("ENTER5");

                    Ti1 = 1 * Math.Round(((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]));
                    Tj1 = 1 * Math.Round(((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[0]]) - Math.Round((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[0]]));
                    fac_TSP = Ti1 + Tj1;
                }
            }


            fac_TSP = orgin_fitness + fac_TSP;
            this.fac_cost.Add(fac_TSP);
            //update
            if (fac_TSP < Population.best_TSP)
            {
                //write_file(Program.sw.ElapsedMilliseconds / 1000, Program.name_file, 2, fac_TSP);
                Population.best_TSP = fac_TSP;
                Console.WriteLine("Population.best_TSP");
                Console.WriteLine(Population.best_TSP);
            }
            return fac_TSP;
        }

        public double latency_tour_swap_edge(ArrayList orgin_tour, ArrayList Lvertex, int i, int j, double orgin_fitness)
        {
            double fac_TRP = 0;
            double n, Ti1, Ti2 = 0;
            n = orgin_tour.Count;

            if (j < orgin_tour.Count - 1)
            {
                Ti1 = (n - i) * ((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]] - (double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]);
                Ti2 = (n - i - 2) * ((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[i + 2]] - (double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[i + 2]]);
                fac_TRP = Ti1 + Ti2;
            }
            else
            {
                Ti1 = (n - i) * ((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]] - (double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]);
                fac_TRP = Ti1;
            }
            fac_TRP = orgin_fitness + fac_TRP;
            this.fac_cost.Add(fac_TRP);

            if (fac_TRP < Population.best_TRP)
            {
                write_file(Program.sw.ElapsedMilliseconds / 1000, Program.name_file, 2, fac_TRP);
                Population.best_TRP = fac_TRP;
                Console.WriteLine("Population.best_TRP");
                Console.WriteLine(Population.best_TRP);
            }
            return fac_TRP;
        }

        public double latency_tour_opt_node(ArrayList orgin_tour, ArrayList Lvertex, int i1, int j1, double orgin_fitness)
        {
            double fac_TRP = 0;
            double n, Ti1, Ti2, Tj1, Tj2 = 0;
            n = orgin_tour.Count;

            int i, j;

            if (i1 < j1)
            {
                i = i1;
                j = j1;
            }
            else
            {
                i = j1;
                j = i1;
            }

            if (j < orgin_tour.Count - 1)
            {
                if (i != (j - 1))
                {
                    //Console.WriteLine("ENTER1");

                    Ti1 = (n - i) * Math.Truncate(((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]]) - Math.Truncate((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]));
                    Ti2 = (n - i - 1) * Math.Truncate(((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[i + 1]]) - Math.Truncate((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[i + 1]]));
                    Tj1 = (n - j) * Math.Truncate(((double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[i]]) - Math.Truncate((double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[j]]));
                    Tj2 = (n - j - 1) * Math.Truncate(((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[j + 1]]) - Math.Truncate((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[j + 1]]));
                    fac_TRP = Ti1 + Ti2 + Tj1 + Tj2;

                }
                else
                {
                    //Console.WriteLine("ENTER2");

                    Ti1 = (n - i) * Math.Truncate(((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]]) - Math.Truncate((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]));
                    Tj2 = (n - j - 1) * Math.Truncate(((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[j + 1]]) - Math.Truncate((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[j + 1]]));
                    fac_TRP = Ti1 + Tj2;
                }
            }
            else
            {
                //Console.WriteLine("ENTER33");

                if (i != (j - 1))
                {
                    //Console.WriteLine("ENTER3");

                    Ti1 = (n - i) * Math.Truncate(((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]]) - Math.Truncate((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]));
                    Ti2 = (n - i - 1) * Math.Truncate(((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[i + 1]]) - Math.Truncate((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[i + 1]]));
                    Tj1 = (n - j) * Math.Truncate(((double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[i]]) - Math.Truncate((double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[j]]));
                    fac_TRP = Ti1 + Ti2 + Tj1;
                }
                else
                {
                    //Console.WriteLine("ENTER4");

                    Ti1 = (n - i) * Math.Truncate(((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]]) - Math.Truncate((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]));
                    fac_TRP = Ti1;
                }
            }


            fac_TRP = orgin_fitness + fac_TRP;
            this.fac_cost.Add(fac_TRP);
            //update
            if (fac_TRP < Population.best_TRP)
            {
                //write_file(Program.sw.ElapsedMilliseconds / 1000, Program.name_file, 2, fac_TRP);
                Population.best_TRP = fac_TRP;
                //Population.best_TRP_Sol = fac_TRP;
                Console.WriteLine("Population.best_TRP");
                Console.WriteLine(Population.best_TRP);
            }
            return fac_TRP;
        }

        public double latency_tour_opt_node_cycle(ArrayList orgin_tour, ArrayList Lvertex, int i1, int j1, double orgin_fitness)
        {
            double fac_TSP = 0;
            double n, Ti1, Ti2, Tj1, Tj2 = 0;
            n = orgin_tour.Count;
            int i, j;
            if (i1 < j1)
            {
                i = i1;
                j = j1;
            }
            else
            {
                i = j1;
                j = i1;
            }

            if (j < orgin_tour.Count - 1)
            {
                //Console.WriteLine("ENTER1");

                if (i != (j - 1))
                {
                    //Console.WriteLine("ENTER2");

                    Ti1 = (n - i + 1) * ((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]] - (double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]);
                    Ti2 = (n - i) * ((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[i + 1]] - (double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[i + 1]]);
                    Tj1 = (n - j + 1) * ((double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[i]] - (double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[j]]);
                    Tj2 = (n - j) * ((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[j + 1]] - (double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[j + 1]]);
                    fac_TSP = Ti1 + Ti2 + Tj1 + Tj2;
                }
                else
                {
                    //Console.WriteLine("ENTER3");

                    Ti1 = (n - i + 1) * ((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]] - (double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]);
                    Tj2 = (n - j) * ((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[j + 1]] - (double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[j + 1]]);
                    fac_TSP = Ti1 + Tj2;
                }
            }
            else
            {
                if (i != (j - 1))
                {
                    //Console.WriteLine("ENTER4");

                    Ti1 = (n - i + 1) * ((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]] - (double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]);
                    Ti2 = (n - i) * ((double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[i + 1]] - (double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[i + 1]]);
                    Tj1 = (n - j + 1) * ((double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[i]] - (double)((Vertex)Lvertex[(int)orgin_tour[j - 1]]).distance_vertex_list[(int)orgin_tour[j]]);
                    Tj2 = 1 * ((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[0]] - (double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[0]]);

                    fac_TSP = Ti1 + Ti2 + Tj1 + Tj2;
                }
                else
                {
                    //Console.WriteLine("ENTER5");

                    Ti1 = (n - i + 1) * ((double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[j]] - (double)((Vertex)Lvertex[(int)orgin_tour[i - 1]]).distance_vertex_list[(int)orgin_tour[i]]);
                    Tj1 = ((double)((Vertex)Lvertex[(int)orgin_tour[i]]).distance_vertex_list[(int)orgin_tour[0]] - (double)((Vertex)Lvertex[(int)orgin_tour[j]]).distance_vertex_list[(int)orgin_tour[0]]);
                    fac_TSP = Ti1 + Tj1;
                }
            }


            fac_TSP = orgin_fitness + fac_TSP;
            this.fac_cost.Add(fac_TSP);
            //update
            if (fac_TSP < Population.best_TSP)
            {
                //write_file(Program.sw.ElapsedMilliseconds / 1000, Program.name_file, 2, fac_TSP);
                Population.best_TSP = fac_TSP;
                Console.WriteLine("Population.best_TSP");
                Console.WriteLine(Population.best_TSP);
            }
            return fac_TSP;
        }

        public double Calculate_fac_TSP(ArrayList Lvertex)
        {

            bool fessible = true;
            double cpk = 0;
            double dpk = 0;
            double fac_TSP = 0;
            double latency = 0;
            //Console.WriteLine(st);
            
            if (dpk < ((Vertex)Lvertex[(int)this.Ltour[0]]).start_time)
            {
                dpk = ((Vertex)Lvertex[(int)this.Ltour[0]]).start_time;
            }

            //length = (double)((Vertex)rdata.Lvertex[(int)Tour[0]]).distance_vertex_list[(int)Tour[1]];
            for (int i = 1; i < Lvertex.Count; i++)
            {
                cpk = (double)((Vertex)Lvertex[(int)this.Ltour[i - 1]]).distance_vertex_list[(int)this.Ltour[i]]// +
                    + (double)((Vertex)Lvertex[(int)this.Ltour[i - 1]]).service_time;
                //Console.WriteLine("Tour");
                //Console.WriteLine(cpk);
                //Console.WriteLine(VertexList[2].end_time);
                //Console.ReadKey();
                //Console.WriteLine(VertexList[(int)Tour[i]].end_time);
                dpk = dpk + cpk;
                if (dpk < ((Vertex)Lvertex[(int)this.Ltour[i]]).start_time)
                {
                    dpk = ((Vertex)Lvertex[(int)this.Ltour[i]]).start_time;
                }
                if (dpk > ((Vertex)Lvertex[(int)this.Ltour[i]]).end_time)
                {
                    fessible = false;
                }
                dpk = dpk - ((Vertex)Lvertex[(int)this.Ltour[0]]).start_time;
                fac_TSP = fac_TSP + (double)((Vertex)Lvertex[(int)this.Ltour[i - 1]]).distance_vertex_list[(int)this.Ltour[i]];
                latency = latency + dpk;
            }

            fac_TSP = fac_TSP + (double)((Vertex)Lvertex[(int)this.Ltour[this.Ltour.Count - 1]]).distance_vertex_list[(int)this.Ltour[0]];
           
            if (fessible == true)
            {
                this.fac_cost.Add(fac_TSP);
                fea = true;
            }
            //else
            //{
            //    fac_TSP = fac_TSP + violation_num * 5;///
            //    fea = false;
            //}

            if ((fac_TSP < Population.best_TSP) && (fessible == true))
            {
                string sol_str = "";

                for (int i = 0; i < this.Ltour.Count; i++)
                {
                    sol_str = sol_str + this.Ltour[i] + " ";
                }

                Population.best_TSP = fac_TSP;
                Population.best_TSP_Sol = (ArrayList)this.Ltour.Clone();
                Console.WriteLine("Population.best_TSP");
                Console.WriteLine(Population.best_TSP);
                Console.WriteLine(latency);

                write_file(Program.sw.ElapsedMilliseconds / 1000, Program.name_file, 1, fac_TSP, sol_str);
            }
            //Console.WriteLine("fessible----fessible");
            //Console.WriteLine(fessible);
            //Console.ReadKey();
            return (fac_TSP);
        }

        public double Calculate_fac_TRP(ArrayList Lvertex)
        {
            bool fessible = true;
            double cpk = 0;
            double dpk = 0;
            int violation_num = 0;
            double fac_TRP = 0;
            double length = 0;
            //string st = "";
            /*
            for (int i = 0; i < Tour.Count; i++)
            {
                st = st + Tour[i] + " ";
                //Console.WriteLine((double)VertexList[(int)Tour[i]].service_time);
            }
            Console.WriteLine(st);
            */
            if (dpk < ((Vertex)Lvertex[(int)this.Ltour[0]]).start_time)
            {
                dpk = ((Vertex)Lvertex[(int)this.Ltour[0]]).start_time;
            }

            //length = (double)((Vertex)rdata.Lvertex[(int)Tour[0]]).distance_vertex_list[(int)Tour[1]];
            for (int i = 1; i < Lvertex.Count; i++)
            {
                cpk = (double)((Vertex)Lvertex[(int)this.Ltour[i - 1]]).distance_vertex_list[(int)this.Ltour[i]]// +
                    + (double)((Vertex)Lvertex[(int)this.Ltour[i - 1]]).service_time;
                //Console.WriteLine("Tour");
                //Console.WriteLine(cpk);
                //Console.WriteLine(VertexList[2].end_time);
                //Console.ReadKey();
                //Console.WriteLine(VertexList[(int)Tour[i]].end_time);
                dpk = dpk + cpk;
                if (dpk < ((Vertex)Lvertex[(int)this.Ltour[i]]).start_time)
                {
                    dpk = ((Vertex)Lvertex[(int)this.Ltour[i]]).start_time;
                }
                if (dpk > ((Vertex)Lvertex[(int)this.Ltour[i]]).end_time)
                {
                    violation_num = violation_num + 1;
                    fessible = false;
                }
                dpk = dpk - ((Vertex)Lvertex[(int)this.Ltour[0]]).start_time;
                fac_TRP = fac_TRP + dpk;
                length = length + (double)((Vertex)Lvertex[(int)this.Ltour[i - 1]]).distance_vertex_list[(int)this.Ltour[i]];

            }
            length = length + (double)((Vertex)Lvertex[(int)this.Ltour[this.Ltour.Count - 1]]).distance_vertex_list[(int)this.Ltour[0]];

            if (fessible == true)
            {
                this.fac_cost.Add(fac_TRP);
                fea = true;
            }
            //else
            //{
            //    fac_TRP = fac_TRP + violation_num * 5;///
            //    fea = false;
            //}

            if ((fac_TRP < Population.best_TRP) && (fessible == true))
            {
                string sol_str = "";

                for (int i = 0; i < this.Ltour.Count; i++)
                {
                    sol_str = sol_str + this.Ltour[i] + " ";
                }

                Population.best_TRP = fac_TRP;
                Population.best_TRP_Sol = (ArrayList)this.Ltour.Clone();
                Console.WriteLine("Population.best_TRP");
                Console.WriteLine(Population.best_TRP);
                Console.WriteLine(length);

                write_file(Program.sw.ElapsedMilliseconds / 1000, Program.name_file, 2, fac_TRP, sol_str);

            }
            //Console.ReadKey();
            return (fac_TRP);
        }

        public void Initial_tour_find_rand(int k_vehicle, int main_depot, int nearest_vertex_number, ArrayList Lvertex, double D, double Q)
        {
            //Console.WriteLine("Initial_tour_find_rand");
            k_vehicle = 1;
            Random rand = new Random();
            ArrayList depot_list = new ArrayList();

            ((Vertex)Lvertex[main_depot]).visited = 1;

            for (int i = 0; i < Lvertex.Count; i++)
            {
                ((Vertex)Lvertex[i]).visited = 0;
            }

            /*for (int i = 0; i < depot_list.Count; i++)
            {
                Console.WriteLine(depot_list[i]);
            }
            Console.ReadKey();
            */
            D = 100000000;
            Q = 100000000;
            k_vehicle = 1;
            for (int i = 0; i < k_vehicle; i++)
            {
                this.Ltour.Add(((Vertex)Lvertex[0]).pos);
                ((Vertex)Lvertex[0]).visited = 1;
            }
            //Console.WriteLine("Lvertex.Count");
            //Console.WriteLine(Lvertex.Count);

            int visited_vertices = 1;
            while (visited_vertices < Lvertex.Count)
            {
                int index = -1;
                ArrayList visited_pos = new ArrayList();
                do
                {
                    index = rand.Next(Lvertex.Count - 1) + 1;
                    //Console.WriteLine("index");
                    //Console.WriteLine(index);

                } while (visited_pos.IndexOf(index) >= 0);
                //Console.WriteLine("index");
                //Console.WriteLine(index);
                visited_pos.Add(index);

                //Console.WriteLine("i");
                //Console.WriteLine(i);

                if (((Vertex)Lvertex[index]).visited == 0)
                {
                    //Console.WriteLine("((Vertex)Lvertex[index]).pos");
                    //Console.WriteLine(((Vertex)Lvertex[index]).pos);
                    this.Ltour.Add(((Vertex)Lvertex[index]).pos);
                    ((Vertex)Lvertex[index]).visited = 1;
                    visited_vertices++;
                }

                //for (int ii = 0; ii < k_vehicle; ii++)
                //{

                //    string line = "";

                //    Console.WriteLine("k_vehicle");
                //    Console.WriteLine(this.Ltour.Count);

                //    for (int j = 0; j < this.Ltour.Count; j++)
                //    {

                //        line = line + " " + this.Ltour[j].ToString();
                //    }
                //    Console.WriteLine(line);
                //    Console.ReadKey();

                //}
            }

            //for (int i = 0; i < k_vehicle; i++)
            //{

            //    string line = "";

            //    Console.WriteLine("k_vehicle");
            //    Console.WriteLine(this.Count);

            //    for (int j = 0; j < this.Ltour.Count; j++)
            //    {

            //        line = line + " " + this.Ltour[j].ToString();
            //    }
            //    Console.WriteLine(line);
            //}
            this.fea = check_fessible_sol(this.Ltour, Lvertex, Program.name_file);
            if (this.fea == false)
            {
                //Console.WriteLine("repair");

                //Console.WriteLine("repair");
                this.Ltour = repair_tour(this.Ltour, Lvertex, Program.name_file);
                //Console.ReadKey();

            }
            this.Calculate_fac_TSP(Lvertex);
            this.Calculate_fac_TRP(Lvertex);




            //Console.ReadKey();
        }

        public void Initial_tour_find_heuristic(int k_vehicle, int main_depot, int nearest_vertex_number, ArrayList Lvertex, double D, double Q, Random rand)
        {
            ArrayList current_tour = new ArrayList();
            ArrayList tem_sol = new ArrayList();
            current_tour.Add(main_depot);
            //Console.WriteLine("Initial_tour_find_heuristic");
            nearest_vertex_number--;
            while (current_tour.Count < Lvertex.Count)
            {
                int number_vertex = -1, v_i = -1, index;
                do
                {
                    index = rand.Next(nearest_vertex_number);
                    number_vertex = (int)((Vertex)Lvertex[(int)current_tour[current_tour.Count - 1]]).nearest_vertex_list[index];
                    if (tem_sol.IndexOf(number_vertex) < 0) tem_sol.Add(number_vertex);
                    if (tem_sol.Count == nearest_vertex_number) break;
                    //Console.WriteLine(index);
                    //Console.WriteLine(number_vertex);
                    //Console.WriteLine(tem_sol.Count); Console.ReadKey();
                }
                while (current_tour.IndexOf(number_vertex) >= 0);

                //Console.WriteLine("OUUUTT");
                if (tem_sol.Count == nearest_vertex_number)
                {
                    do
                    {
                        v_i = rand.Next(Lvertex.Count);
                    }
                    while (current_tour.IndexOf(v_i) >= 0);
                    current_tour.Add(v_i);
                }
                else
                {
                    current_tour.Add(number_vertex);
                }
                tem_sol.Clear();
            }
            this.Ltour = (ArrayList)current_tour.Clone();

            //for (int i = 0; i < k_vehicle; i++)
            //{

            //    string line = "";

            //    Console.WriteLine("k_vehicle");
            //    Console.WriteLine(this.Count);

            //    for (int j = 0; j < this.Ltour.Count; j++)
            //    {

            //        line = line + " " + this.Ltour[j].ToString();
            //    }
            //    Console.WriteLine(line);
            //    //Console.ReadKey();

            //}

            this.fea = check_fessible_sol(this.Ltour, Lvertex, Program.name_file);
            if (this.fea == false)
            {
                //Console.WriteLine("repair");
                this.Ltour = repair_tour(this.Ltour, Lvertex, Program.name_file);
                //Console.ReadKey();
            }
            this.Calculate_fac_TSP(Lvertex);
            this.Calculate_fac_TRP(Lvertex);
        }

        public bool check_fessible_sol(ArrayList tour, ArrayList Lvertex, string fileName)
        {
            //Console.WriteLine(fileName);

            bool fessible = true;
            double cpk = 0;
            double dpk = 0;
            //double latency = 0;
            //double length = 0;

            //string st = "";
            /*
            for (int i = 0; i < Tour.Count; i++)
            {
                st = st + Tour[i] + " ";
                //Console.WriteLine((double)VertexList[(int)Tour[i]].service_time);
            }
            Console.WriteLine(st);
            */
            if (dpk < ((Vertex)Lvertex[(int)tour[0]]).start_time)
            {
                dpk = ((Vertex)Lvertex[(int)tour[0]]).start_time;
            }

            //length = (double)((Vertex)rdata.Lvertex[(int)Tour[0]]).distance_vertex_list[(int)Tour[1]];
            for (int i = 1; i < tour.Count; i++)
            {
                cpk = (double)((Vertex)Lvertex[(int)tour[i - 1]]).distance_vertex_list[(int)tour[i]]// +
                    + (double)((Vertex)Lvertex[(int)tour[i - 1]]).service_time;
                dpk = dpk + cpk;
                if (dpk < ((Vertex)Lvertex[(int)tour[i]]).start_time)
                {
                    dpk = ((Vertex)Lvertex[(int)tour[i]]).start_time;
                }
                if (dpk > ((Vertex)Lvertex[(int)tour[i]]).end_time)
                {
                    fessible = false;
                    break;
                }
                dpk = dpk - ((Vertex)Lvertex[(int)tour[0]]).start_time;
                //latency = latency + dpk;
                //length = length + (double)((Vertex)Lvertex[(int)tour[i - 1]]).distance_vertex_list[(int)tour[i]];
            }
            //length = length + (double)((Vertex)Lvertex[(int)tour[tour.Count - 1]]).distance_vertex_list[(int)tour[0]];

            //if (fessible == true)
            //{
            //    if (TSPTW_total_min > length)
            //    {
            //        Console.WriteLine("length");
            //        Console.WriteLine(length);
            //        //Console.ReadKey();
            //        //write_file_true(Tour, latency, fileName);
            //        TSPTW_total_min = length;
            //        //total_min_tour = (ArrayList)Tour.Clone();
            //    }
            //    if (TRPTW_total_min > latency)
            //    {
            //        Console.WriteLine("latency");
            //        Console.WriteLine(latency);
            //        //Console.ReadKey();
            //        //write_file_true(Tour, latency, fileName);
            //        TRPTW_total_min = latency;
            //        //total_min_tour = (ArrayList)Tour.Clone();
            //    }
            //}
            //Console.ReadKey();
            //Console.WriteLine("fessible");
            //Console.WriteLine(fessible);
            return (fessible);
        }

        public void check_sol(ArrayList Ltour)
        {
            bool fea = true;
            for (int i = 0; i < Ltour.Count - 1; i++)
            {
                for (int j = i + 1; j < Ltour.Count; j++)
                {
                    if (Ltour[i] == Ltour[j])
                    {
                        fea = false;
                        break;
                    }
                }
            }
            if (Ltour.Count != 51)
            {
                fea = false;
            }
            this.fea = fea;
        }

        public void write_file(double running_time, string name_instances, int num, double fac)
        {
            string str;
            if (num == 1)
                str = "TSP-MFEA-time-" + name_instances;
            else
                str = "TRP-MFEA-time-" + name_instances;

            StreamWriter sr = new StreamWriter(str, true);

            try
            {
                sr.WriteLine(running_time.ToString() + "----" + fac.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            sr.Close();
        }

        public void write_file(double running_time, string name_instances, int num, double fac, string sol_str)
        {
            string str;
            if (num == 1)
                str = "TSP-MFEA-time-" + name_instances;
            else
                str = "TRP-MFEA-time-" + name_instances;

            StreamWriter sr = new StreamWriter(str, true);

            try
            {
                sr.WriteLine(running_time.ToString() + "----" + fac.ToString() + "----" + sol_str);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            sr.Close();
        }

        public ArrayList simple_swap_mutation(ArrayList initial_tour, ArrayList Lvertex, Random rand, int diversity_value)
        {
            ArrayList new_tour = new ArrayList();
            new_tour = (ArrayList)initial_tour.Clone();

            int number, i, j, k;
            number = diversity_value;

            for (k = 0; k < number; k++)
            {
                do
                {
                    i = rand.Next(initial_tour.Count);

                } while (i <= 0);

                do
                {
                    j = rand.Next(initial_tour.Count);

                } while ((j <= 0) || (i == j));

                int t = (int)new_tour[i];
                new_tour[i] = (int)new_tour[j];
                new_tour[j] = t;

                if (i < j)
                {
                    new_tour.Reverse(i, j - i - 1);
                }
                else
                {
                    new_tour.Reverse(j, i - j - 1);
                }
            }
            initial_tour = (ArrayList)new_tour.Clone();
            return (initial_tour);
        }
        public double new_latency_tour(ArrayList tour, ArrayList Lvertex)
        {
            double cost = 0;

            /*for (int i = 0; i < tour.Count - 1; i++)
            {
                latency = latency + (double)(tour.Count - 1 - i) * (double)VertexList[(int)tour[i]].distance_vertices[(int)tour[i + 1]];
            }
            return latency;
            */

            double apk = 0;
            double cpk = 0;
            double dpk = 0;
            double new_cost = 0;

            /*for (int i = 0; i < Tour.Count; i++)
            {
                st = st + Tour[i] + " ";
            }
            Console.WriteLine(st);*/

            dpk = ((Vertex)Lvertex[(int)tour[0]]).start_time;

            for (int i = 1; i < this.Ltour.Count; i++)
            {
                cpk = (double)((Vertex)Lvertex[(int)tour[i - 1]]).distance_vertex_list[(int)tour[i]] +
                    (double)((Vertex)Lvertex[(int)tour[i - 1]]).service_time;

                dpk = dpk + cpk;

                if (dpk < ((Vertex)Lvertex[(int)tour[i]]).start_time)
                {
                    dpk = ((Vertex)Lvertex[(int)tour[i]]).start_time;
                }

                new_cost = dpk - ((Vertex)Lvertex[(int)tour[i]]).end_time;

                if (new_cost > 0)
                {
                    cost = cost + new_cost;
                }
                else
                {
                    new_cost = 0;
                    cost = cost + new_cost;
                }
            }
            return cost;
        }
        public ArrayList repair_tour(ArrayList tour, ArrayList Lvertex, string fileName)
        {
            double local_cost = (double)new_latency_tour(tour, Lvertex);

            int l_max = 10;
            int diversity_value = 5;
            ArrayList new_tour = new ArrayList();
            Random rand = new Random();

            while ((check_fessible_sol(tour, Lvertex, fileName) == false) && (diversity_value < l_max))
            {
                //Console.WriteLine("diversity_value");
                new_tour = (ArrayList)this.Ltour.Clone();

                /*string st = "";
                //Console.ReadKey();

                for (int i = 0; i < post_tour.Count; i++)
                {
                    st = st + post_tour[i] + " ";
                }
                Console.WriteLine(st);*/

                new_tour = (ArrayList)simple_swap_mutation(new_tour, Lvertex, rand, diversity_value);

                /*st = "";
                for (int i = 0; i < post_tour.Count; i++)
                {
                    st = st + post_tour[i] + " ";
                }
                Console.WriteLine(st);*/

                local_cost = (double)new_latency_tour(new_tour, Lvertex);

                //Console.WriteLine("local_cost");
                //Console.WriteLine(local_cost);

                new_tour = (ArrayList)VNS(new_tour, local_cost, Lvertex, rand, fileName);

                /*st = "";
                for (int i = 0; i < post_tour.Count; i++)
                {
                    st = st + post_tour[i] + " ";
                }
                Console.WriteLine(st);*/
                //Console.ReadKey();
                double after_local_cost = (double)new_latency_tour(new_tour, Lvertex);
                //Console.WriteLine("after_local_cost");
                //Console.WriteLine(after_local_cost);

                if (after_local_cost < local_cost)
                {
                    /*st = "";
                    for (int i = 0; i < post_tour.Count; i++)
                    {
                        st = st + post_tour[i] + " ";
                    }
                    Console.WriteLine(st);*/

                    tour = (ArrayList)new_tour.Clone();
                    local_cost = after_local_cost;
                }

                if (after_local_cost == local_cost)
                {
                    diversity_value = 1;
                }
                else
                {
                    diversity_value++;
                }
                //Console.WriteLine("yes");
                /*st = "";
                for (int i = 0; i < current_tour.Count; i++)
                {
                    st = st + current_tour[i] + " ";
                }
                Console.WriteLine(st);*/
                //Console.WriteLine("BHB");
                //Console.WriteLine(check_fessible_sol(tour, Lvertex, fileName));
                if (check_fessible_sol(tour, Lvertex, fileName) == true)
                {
                    this.fea = true;
                    break;
                }
            }
            //this.Ltour = (ArrayList)tour.Clone();
            //while (check_fessible_sol(current_tour, VertexList, "BHB") == false);
            return (ArrayList)tour.Clone();
        }
        public ArrayList VNS(ArrayList current_tour, double current_cost, ArrayList Lvertex, Random rand, string fileName)
        {
            ArrayList temp_current_tour = new ArrayList();
            double temp_current_cost = 0;

            temp_current_tour = (ArrayList)current_tour.Clone();
            temp_current_cost = current_cost;

            for (int i = 0; i < 8; i++)
            {
                ArrayList post_tour = new ArrayList();
                //Console.WriteLine("temp_current_cost"); Console.WriteLine(temp_current_cost);
                if (i == 0)
                {
                    post_tour = new_swap_adjacent(temp_current_tour, Lvertex, temp_current_cost, fileName);
                    //Console.WriteLine("local_cost"); Console.WriteLine(local_cost);
                    //Console.ReadKey();
                    if (local_cost < temp_current_cost)
                    {
                        temp_current_cost = local_cost;
                        temp_current_tour = (ArrayList)post_tour.Clone();
                        i = 0;
                    }
                    post_tour.Clear();
                }
                else
                if (i == 1)
                {
                    post_tour = new_remove_insert(temp_current_tour, Lvertex, temp_current_cost, fileName);
                    if (local_cost < temp_current_cost)
                    {
                        temp_current_cost = local_cost;
                        temp_current_tour = (ArrayList)post_tour.Clone();
                        i = 0;
                    }
                    post_tour.Clear();
                }
                else
                if (i == 2)
                {

                    post_tour = new_move_down_full(temp_current_tour, Lvertex, temp_current_cost, fileName);
                    if (local_cost < temp_current_cost)
                    {
                        temp_current_cost = local_cost;
                        temp_current_tour = (ArrayList)post_tour.Clone();
                        i = 0;
                    }
                    post_tour.Clear();
                }
                else
                if (i == 3)
                {
                    post_tour = new_move_up_full(temp_current_tour, Lvertex, temp_current_cost, fileName);
                    if (local_cost < temp_current_cost)
                    {
                        temp_current_cost = local_cost;
                        temp_current_tour = (ArrayList)post_tour.Clone();
                        i = 0;
                    }
                    post_tour.Clear();
                }
                else
                if (i == 4)
                {
                    post_tour = new_improve_greedy_two_opt(temp_current_tour, Lvertex, temp_current_cost, fileName);
                    if (local_cost < temp_current_cost)
                    {
                        temp_current_cost = local_cost;
                        temp_current_tour = (ArrayList)post_tour.Clone();
                        i = 0;
                    }
                    post_tour.Clear();
                }
                else
                if (i == 5)
                {
                    post_tour = new_greedy_two_edge_opt(temp_current_tour, Lvertex, temp_current_cost, fileName);
                    if (local_cost < temp_current_cost)
                    {
                        temp_current_cost = local_cost;
                        temp_current_tour = (ArrayList)post_tour.Clone();
                        i = 0;
                    }
                    post_tour.Clear();
                }
                else
                {
                    if (i == 6)
                    {
                        post_tour = new_first_greedy_three_opt(temp_current_tour, Lvertex, temp_current_cost, fileName);
                        if (local_cost < temp_current_cost)
                        {
                            temp_current_cost = local_cost;
                            temp_current_tour = (ArrayList)post_tour.Clone();
                            i = 0;
                        }
                        post_tour.Clear();
                    }
                    else
                    {
                        if (i == 7)
                        {
                            post_tour = new_two_greedy_three_opt(temp_current_tour, Lvertex, temp_current_cost, fileName);
                            if (local_cost < temp_current_cost)
                            {
                                temp_current_cost = local_cost;
                                temp_current_tour = (ArrayList)post_tour.Clone();
                                i = 0;
                            }
                            post_tour.Clear();
                        }

                    }
                }
            }
            return (ArrayList)temp_current_tour.Clone();
        }
        public ArrayList new_swap_adjacent(ArrayList initial_tour, ArrayList Lvertex, double before_cost, string fileName)
        {
            ArrayList tem_tour = new ArrayList();
            tem_tour = (ArrayList)initial_tour.Clone();
            int i, j;
            local_cost = 0;

            bool improve = true;
            if (initial_tour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;
                    while (i < tem_tour.Count - 1)
                    {
                        j = i + 1;
                        //local_cost = (double)latency_tour_swap_edge(tem_tour, VertexList, i, j, before_cost);
                        int t = (int)tem_tour[i];
                        tem_tour[i] = (int)tem_tour[j];
                        tem_tour[j] = (int)t;

                        local_cost = (double)new_latency_tour(tem_tour, Lvertex);
                        check_fessible_sol(tem_tour, Lvertex, fileName);

                        if ((double)local_cost < (double)before_cost)
                        {
                            improve = true;
                            before_cost = (double)local_cost;
                            //check_fessible_sol(tem_tour, VertexList, fileName);
                        }
                        else
                        {
                            t = (int)tem_tour[i];
                            tem_tour[i] = (int)tem_tour[j];
                            tem_tour[j] = (int)t;
                        }
                        if (improve == true) break;
                        else
                            i++;
                    }
                }
            }
            else
            {
                local_cost = before_cost;
            }
            local_cost = before_cost;
            return tem_tour;
        }
        public ArrayList new_remove_insert(ArrayList initial_tour, ArrayList Lvertex, double before_cost, string fileName)
        {
            ArrayList tem_tour = new ArrayList();
            ArrayList tour_change = new ArrayList();
            tem_tour = (ArrayList)initial_tour.Clone();

            int i;
            local_cost = 0;

            bool improve = true;
            if (initial_tour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;
                    while (i < tem_tour.Count - 1)
                    {
                        tour_change = (ArrayList)tem_tour.Clone();
                        tour_change.RemoveAt(i);
                        tour_change.Add((int)tem_tour[i]);

                        local_cost = (double)new_latency_tour(tour_change, Lvertex);
                        check_fessible_sol(tem_tour, Lvertex, fileName);
                        if ((double)local_cost < (double)before_cost)
                        {
                            tem_tour = (ArrayList)tour_change.Clone();
                            before_cost = (double)local_cost;
                            improve = true;
                            //check_fessible_sol(tem_tour, VertexList, fileName);
                        }
                        if (improve == true) break;
                        else
                            i++;
                    }
                }
            }
            else
            {
                local_cost = before_cost;
            }

            local_cost = before_cost;
            //initial_tour = (ArrayList)tem_tour.Clone();
            //Console.WriteLine("local_cost.ToString()");
            //Console.WriteLine(local_cost.ToString());
            return (tem_tour);
        }
        public ArrayList new_move_down_full(ArrayList initial_tour, ArrayList Lvertex, double before_cost, string fileName)
        {
            ArrayList tem_tour = new ArrayList();
            tem_tour = (ArrayList)initial_tour.Clone();
            int i, j;
            local_cost = 0;

            if (initial_tour.Count >= 3)
            {
                i = 1;
                while (i < tem_tour.Count - 1)
                {
                    j = i + 1;
                    while (j < tem_tour.Count - 2)
                    {
                        int t = (int)tem_tour[i];
                        tem_tour[i] = (int)tem_tour[j];
                        tem_tour[j] = (int)t;
                        //local_cost = (double)latency_tour_opt_node(tem_tour, tem_tour, VertexList, i, j, before_cost);
                        local_cost = (double)new_latency_tour(tem_tour, Lvertex);
                        check_fessible_sol(tem_tour, Lvertex, fileName);

                        if ((double)local_cost < (double)before_cost)
                        {
                            before_cost = (double)local_cost;
                            //check_fessible_sol(tem_tour, VertexList, fileName);
                        }
                        else
                        {
                            t = (int)tem_tour[i];
                            tem_tour[i] = (int)tem_tour[j];
                            tem_tour[j] = (int)t;
                        }
                        j++;
                    }
                    i++;
                }
            }
            else
            {
                local_cost = before_cost;
            }

            local_cost = before_cost;
            //initial_tour = (ArrayList)tem_tour.Clone();

            //Console.WriteLine(local_cost.ToString());
            return (tem_tour);
        }
        public ArrayList new_move_up_full(ArrayList initial_tour, ArrayList Lvertex, double before_cost,string fileName)
        {
            ArrayList tem_tour = new ArrayList();
            tem_tour = (ArrayList)initial_tour.Clone();
            int i, j;
            local_cost = 0;
            if (initial_tour.Count >= 3)
            {
                i = initial_tour.Count - 2;
                while (i > 1)
                {
                    j = i - 1;
                    while (j > 0)
                    {
                        int t = (int)tem_tour[i];
                        tem_tour[i] = (int)tem_tour[j];
                        tem_tour[j] = (int)t;
                        //local_cost = (double)latency_tour_opt_node(temp_tour, temp_tour, VertexList, i, j, before_cost);
                        local_cost = (double)new_latency_tour(tem_tour, Lvertex);
                        //check_fessible_sol(tem_tour, Lvertex, fileName);

                        if ((double)local_cost < (double)before_cost)
                        {
                            before_cost = (double)local_cost;
                            //check_fessible_sol(temp_tour, VertexList, fileName);
                        }
                        else
                        {
                            t = (int)tem_tour[i];
                            tem_tour[i] = (int)tem_tour[j];
                            tem_tour[j] = (int)t;
                        }
                        j--;
                    }
                    i--;
                }
            }
            else
            {
                local_cost = before_cost;
            }
            local_cost = before_cost;
            return (tem_tour);
        }
        public ArrayList new_improve_greedy_two_opt(ArrayList initial_tour, ArrayList Lvertex, double before_cost, string fileName)
        {
            ArrayList temp_tour = new ArrayList();
            temp_tour = (ArrayList)initial_tour.Clone();
            int i, j;
            local_cost = 0;
            bool improve = true;

            if (initial_tour.Count >= 3)
            {
                while (improve == true)
                {
                    i = 1;
                    improve = false;

                    while (i < temp_tour.Count - 1)
                    {
                        j = i + 2;
                        while (j < temp_tour.Count)
                        {
                            int t;

                            ///t = (int)temp_tour[i+1];
                            //temp_tour[i+1] = (int)temp_tour[j];
                            //temp_tour[j] = (int)t;

                            ArrayList tmp_temp_tour = new ArrayList();
                            tmp_temp_tour = (ArrayList)temp_tour.Clone();
                            tmp_temp_tour.Reverse(i, j - i - 1);
                            double local_cost = (double)new_latency_tour(tmp_temp_tour, Lvertex);
                            //check_fessible_sol(tmp_temp_tour, Lvertex, fileName);

                            if ((double)local_cost < (double)before_cost)
                            {
                                before_cost = (double)local_cost;
                                improve = true;
                                temp_tour = (ArrayList)tmp_temp_tour.Clone();
                                //check_fessible_sol(temp_tour, VertexList, fileName);
                            }
                            if (improve == true) break;
                            else j++;
                        }
                        if (improve == true) break;
                        else i++;
                    }
                }
            }
            else
            {
                local_cost = before_cost;
            }
            local_cost = before_cost;
            //initial_tour = (ArrayList)temp_tour.Clone();
            //tour_change.Clear();
            //temp_tour.Clear();
            //Console.WriteLine("local_cost.ToString()");
            //Console.WriteLine(local_cost.ToString());
            return temp_tour;
        }
        public ArrayList new_greedy_two_edge_opt(ArrayList initial_tour, ArrayList Lvertex, double fitness_before, string fileName)
        {
            ArrayList tour_current = new ArrayList();
            tour_current = (ArrayList)initial_tour.Clone();
            int i, j;
            local_cost = 0;
            if (initial_tour.Count >= 3)
            {
                i = 1;
                while (i < tour_current.Count - 2)
                {
                    j = i + 2;
                    while (j < tour_current.Count)
                    {
                        ArrayList tmp_tour_current = new ArrayList();
                        tmp_tour_current = (ArrayList)tour_current.Clone();
                        tmp_tour_current.Reverse(i, j - i + 1);
                        double local_cost = (double)new_latency_tour(tmp_tour_current, Lvertex);
                        //check_fessible_sol(tmp_tour_current, Lvertex, fileName);

                        if ((double)local_cost < (double)fitness_before)
                        {
                            tour_current = (ArrayList)tmp_tour_current.Clone();
                            fitness_before = (double)local_cost;
                        }
                        j++;
                    }
                    i++;
                }
            }
            else
            {
                local_cost = fitness_before;
            }
            local_cost = fitness_before;

            return tour_current;
        }
        public ArrayList new_first_greedy_three_opt(ArrayList tour, ArrayList Lvertex, double fitness_before, string fileName)
        {
            ArrayList tmp_tour = new ArrayList();
            local_cost = 0;
            tmp_tour = (ArrayList)tour.Clone();

            int i = 1, j = 2, k = 3;
            while (i < tmp_tour.Count)
            {
                j = i + 1;
                while (j < tmp_tour.Count - 1)
                {
                    k = j + 1;
                    while (k < tmp_tour.Count)
                    {
                        int tg;

                        tg = (int)tmp_tour[i];
                        tmp_tour[i] = (int)tmp_tour[j];
                        tmp_tour[j] = tg;

                        tg = (int)tmp_tour[k];
                        tmp_tour[k] = (int)tmp_tour[j];
                        tmp_tour[j] = tg;

                        //local_cost = (double)latency_tour(first_tour_change, second_tour_change, VertexList, j, k, first_fitness);
                        local_cost = (double)new_latency_tour(tmp_tour, Lvertex);
                        //check_fessible_sol(tmp_tour, Lvertex, fileName);

                        //double fitness_after = (double)local_cost;

                        if (local_cost < fitness_before)
                        {
                            fitness_before = local_cost;
                        }
                        else
                        {
                            tg = (int)tmp_tour[k];
                            tmp_tour[k] = (int)tmp_tour[j];
                            tmp_tour[j] = tg;

                            tg = (int)tmp_tour[i];
                            tmp_tour[i] = (int)tmp_tour[j];
                            tmp_tour[j] = tg;
                        }
                        k++;
                    }
                    j++;
                }
                i++;

            }


            ArrayList after_tour = new ArrayList();
            after_tour = (ArrayList)tmp_tour.Clone();
            local_cost = fitness_before;
            return (after_tour);
        }
        public ArrayList new_two_greedy_three_opt(ArrayList tour, ArrayList Lvertex, double fitness_before, string fileName)
        {
            ArrayList tmp_tour = new ArrayList();
            local_cost = 0;
            tmp_tour = (ArrayList)tour.Clone();

            int i = 1, j = 2, k = 3;
            while (i < tmp_tour.Count)
            {
                j = i + 1;
                while (j < tmp_tour.Count - 1)
                {
                    k = j + 1;
                    while (k < tmp_tour.Count)
                    {
                        int tg; ;

                        tg = (int)tmp_tour[i];
                        tmp_tour[i] = (int)tmp_tour[k];
                        tmp_tour[k] = tg;

                        tg = (int)tmp_tour[k];
                        tmp_tour[k] = (int)tmp_tour[j];
                        tmp_tour[j] = tg;

                        //local_cost = (double)latency_tour(first_tour_change, second_tour_change, VertexList, j, k, first_fitness);
                        local_cost = (double)new_latency_tour(tmp_tour, Lvertex);
                        //check_fessible_sol(tmp_tour, Lvertex, fileName);

                        //double fitness_after = (double)local_cost;

                        if (local_cost < fitness_before)
                        {
                            fitness_before = local_cost;
                        }
                        else
                        {
                            tg = (int)tmp_tour[k];
                            tmp_tour[k] = (int)tmp_tour[j];
                            tmp_tour[j] = tg;

                            tg = (int)tmp_tour[i];
                            tmp_tour[i] = (int)tmp_tour[k];
                            tmp_tour[k] = tg;
                        }
                        k++;
                    }
                    j++;
                }
                i++;

            }


            ArrayList after_tour = new ArrayList();
            after_tour = (ArrayList)tmp_tour.Clone();
            local_cost = fitness_before;
            return (after_tour);
        }

    }

}
