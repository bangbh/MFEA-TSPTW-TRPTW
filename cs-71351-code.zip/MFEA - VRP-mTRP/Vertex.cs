﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;


namespace MFEA
{
    class Vertex
    {

        //public int type;
        public int pos;
        public double x;
        public double y;
        public int visited = 0;
        public ArrayList nearest_vertex_list = new ArrayList();
        public ArrayList distance_vertex_list = new ArrayList();
        public double start_time;
        public double end_time;
        public double service_time;
        public double travel_time = 0;
        public double demand = 0;
        public int number = 0;

        //public Vertex(int cus_type, int cus_pos, double x_location, double y_location, double duration, double demand, int cus_visited)
        public Vertex(int pos_num, double x_location, double y_location, double start, double end, double ser_time, double dem)
        {
            pos = pos_num;
            x = x_location;
            y = y_location;
            start_time = start;
            end_time = end;
            service_time = ser_time;
            demand = dem;
        }

        public void Nearest_vertex_find(int nearest_vertex_number)
        {
            double nearest_distance;
            int nearest_vertex = 0;
            double[] dist = new double[distance_vertex_list.Count];

            distance_vertex_list.CopyTo(dist);

            if (nearest_vertex_number > distance_vertex_list.Count)
            {
                nearest_vertex_number = distance_vertex_list.Count;
            }
            nearest_vertex_list.Clear();

            for (int i = 0; i < nearest_vertex_number; i++)
            {
                nearest_distance = double.MaxValue;
                for (int vertex_num = 0; vertex_num < nearest_vertex_number; vertex_num++)
                {
                    if ((double)dist[vertex_num] < nearest_distance)
                    {
                        nearest_distance = (double)dist[vertex_num];
                        nearest_vertex = vertex_num;
                    }
                }

                if (nearest_distance != 0)
                {
                    nearest_vertex_list.Add(nearest_vertex);
                }
                dist[nearest_vertex] = double.MaxValue;
            }
        }
    }
}
