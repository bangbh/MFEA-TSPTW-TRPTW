﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace MFEA
{
    class Route : ArrayList

    {
        public double fac_TSP = 0;
        public double fac_TRP = 0;
        public double skill_factor = 0;
        public double scalar_fitness = 0;
        public ArrayList Lroute = new ArrayList();

        public double Calculate_fac_TSP(ArrayList lroute, ArrayList Lvertex)
        {
            fac_TSP = 0;
            for (int i = 0; i < lroute.Count - 1; i++)
            {
                fac_TSP = fac_TSP + (double)((Vertex)Lvertex[(int)lroute[i]]).distance_vertex_list[(int)lroute[i + 1]];
            }
            fac_TSP = fac_TSP + (double)((Vertex)Lvertex[(int)lroute[lroute.Count - 1]]).distance_vertex_list[(int)lroute[0]];
            return fac_TSP;
        }

        public double Calculate_fac_TRP(ArrayList lroute, ArrayList Lvertex)
        {
            fac_TRP = 0;
            for (int i = 0; i < lroute.Count - 1; i++)
            {
                fac_TRP = fac_TRP + (double)(lroute.Count - 1 - i) * (double)((Vertex)Lvertex[(int)lroute[i]]).distance_vertex_list[(int)lroute[i + 1]];
            }
            return fac_TRP;
        }
    }
}
    
